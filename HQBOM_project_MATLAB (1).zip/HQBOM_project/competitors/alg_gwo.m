function R = alg_gwo(prob, maxFE, o)
%ALG_GWO  Grey Wolf Optimizer (Mirjalili et al. 2014), N = 50, a: 2 -> 0.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub;
X = lb + rand(N,D).*(ub-lb);
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; a = 2 - 2*min(t/T,1);
    [~, s] = sort(K); L = X(s(1:min(3,N)),:);
    if size(L,1) < 3, L = repmat(L(1,:),3,1); end
    Xn = zeros(N,D);
    for k = 1:3
        A = 2*a*rand(N,D) - a; C = 2*rand(N,D);
        Xn = Xn + (L(k,:) - A.*abs(C.*L(k,:) - X));
    end
    X = min(max(Xn/3, lb), ub);
    [~,~,Xe,S,Ke] = fe_eval(S, X); n = numel(Ke); if n == 0, break; end
    X(1:n,:) = Xe; K(1:n) = Ke;
end
R = run_result(S);
end
