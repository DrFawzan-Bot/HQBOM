function R = alg_lshade(prob, maxFE, o)
%ALG_LSHADE  Wrapper for shade_family(..., 'lshade').
R = shade_family(prob, maxFE, 'lshade');
end
