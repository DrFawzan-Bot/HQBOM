function R = alg_ao(prob, maxFE, o)
%ALG_AO  Aquila Optimizer (Abualigah et al. 2021), N = 50,
%   alpha = delta = 0.1, Levy beta = 1.5, spiral r1 = 10, U = 0.00565,
%   omega = 0.005; greedy replacement (reference code).
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
alpha = 0.1; delta = 0.1;
Dv = 1:D; U = 0.00565; r1s = 10; omega = 0.005;
rr = r1s + U*Dv; th = -omega*Dv + 3*pi/2;
yy = rr.*cos(th); xx = rr.*sin(th);
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    Xb = S.bestX; Xm = mean(X,1);
    QF = tt^((2*rand - 1)/(1 - T)^2);
    G2 = 2*(1 - tt/T);
    Xn = zeros(N,D);
    if tt <= (2/3)*T
        sel = rand(N,1) < 0.5;
        X1 = Xb.*(1 - tt/T) + (Xm - Xb.*rand(N,1));
        X2 = Xb.*levy_flight(N,D) + X(randi(N,N,1),:) + (yy - xx).*rand(N,1);
        Xn(sel,:) = X1(sel,:); Xn(~sel,:) = X2(~sel,:);
    else
        sel = rand(N,1) < 0.5;
        X3 = (Xb - Xm)*alpha - rand(N,1) + (rg.*rand(N,D) + lb)*delta;
        G1 = 2*rand(N,1) - 1;
        X4 = QF*Xb - (G1.*X.*rand(N,1)) - G2.*levy_flight(N,D) + rand(N,1).*G1;
        Xn(sel,:) = X3(sel,:); Xn(~sel,:) = X4(~sel,:);
    end
    Xn = min(max(Xn, lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    b = Kn <= K(1:n); idx = find(b); X(idx,:) = Xn(b,:); K(idx) = Kn(b);
end
R = run_result(S);
end
