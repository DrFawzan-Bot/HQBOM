function R = alg_rsa(prob, maxFE, o)
%ALG_RSA  Reptile Search Algorithm (Abualigah et al. 2022), N = 50,
%   alpha = 0.1, beta = 0.005; greedy replacement (reference code).
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
al = 0.1; be = 0.005; e = realmin;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    Xb = S.bestX;
    ES = 2*(2*rand - 1)*(1 - tt/T);
    Xm = mean(X, 2);
    P  = al + (X - Xm) ./ (Xb.*rg + e);
    eta = Xb .* P;
    r2 = randi(N, N, 1); r1 = randi(N, N, 1);
    Rr = (Xb - X(r2,:)) ./ (Xb + e);
    if tt <= T/4
        Xn = Xb - eta*be - Rr.*rand(N,D);
    elseif tt <= T/2
        Xn = Xb .* X(r1,:) * ES .* rand(N,D);
    elseif tt <= 3*T/4
        Xn = Xb .* P .* rand(N,D);
    else
        Xn = Xb - eta*e - Rr.*rand(N,D);
    end
    Xn = min(max(Xn, lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    b = Kn <= K(1:n); idx = find(b); X(idx,:) = Xn(b,:); K(idx) = Kn(b);
end
R = run_result(S);
end
