function r = rand_distinct(N, k)
%RAND_DISTINCT  N-by-k random indices in 1..N, distinct within each row
%   and different from the row index (vectorised rejection sampling).
r = zeros(N, k);
for c = 1:k
    r(:,c) = randi(N, N, 1);
    bad = r(:,c) == (1:N)' | any(r(:,1:c-1) == r(:,c), 2);
    while any(bad)
        r(bad,c) = randi(N, nnz(bad), 1);
        bad = r(:,c) == (1:N)' | any(r(:,1:c-1) == r(:,c), 2);
    end
end
end
