function R = alg_hba(prob, maxFE, o)
%ALG_HBA  Honey Badger Algorithm (Hashim et al. 2022), N = 50,
%   C = 2, beta = 6; greedy replacement.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0; C = 2; beta = 6;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    Xb = S.bestX;
    alpha = C*exp(-tt/T);
    di = Xb - X;
    Sd = sum((X - X([2:N 1],:)).^2, 2);
    I = rand(N,1) .* Sd ./ (4*pi*sum(di.^2,2) + eps);
    F = 2*(rand(N,1) < 0.5) - 1;
    dig = rand(N,1) < 0.5;
    Xn = zeros(N,D);
    r3 = rand(N,D); r4 = rand(N,D); r5 = rand(N,D);
    Xd = Xb + F.*beta.*I.*Xb + F.*r3.*alpha.*di.*abs(cos(2*pi*r4).*(1 - cos(2*pi*r5)));
    Xh = Xb + F.*rand(N,D).*alpha.*di;
    Xn(dig,:) = Xd(dig,:); Xn(~dig,:) = Xh(~dig,:);
    Xn = min(max(Xn, lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    b = Kn <= K(1:n); idx = find(b); X(idx,:) = Xn(b,:); K(idx) = Kn(b);
end
R = run_result(S);
end
