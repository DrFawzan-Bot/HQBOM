function R = alg_ilshade(prob, maxFE, o)
%ALG_ILSHADE  Wrapper for shade_family(..., 'ilshade').
R = shade_family(prob, maxFE, 'ilshade');
end
