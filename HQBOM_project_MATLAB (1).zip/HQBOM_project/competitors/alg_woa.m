function R = alg_woa(prob, maxFE, o)
%ALG_WOA  Whale Optimization Algorithm (Mirjalili & Lewis 2016), N = 50,
%   a: 2 -> 0, a2: -1 -> -2, spiral constant b = 1 (vectorised form).
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub;
X = lb + rand(N,D).*(ub-lb);
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; tau = min(t/T,1); a = 2 - 2*tau; a2 = -1 - tau;
    [~, g] = min(K); Xb = X(g,:);
    A = 2*a*rand(N,1) - a; C = 2*rand(N,1); p = rand(N,1);
    l = (a2-1)*rand(N,1) + 1;
    Xr = X(randi(N,N,1),:);
    Xenc = Xb - A.*abs(C.*Xb - X);
    Xexp = Xr - A.*abs(C.*Xr - X);
    Xsp  = abs(Xb - X).*exp(l).*cos(2*pi*l) + Xb;
    Xn = Xsp;
    m1 = p < 0.5 & abs(A) <  1; Xn(m1,:) = Xenc(m1,:);
    m2 = p < 0.5 & abs(A) >= 1; Xn(m2,:) = Xexp(m2,:);
    X = min(max(Xn, lb), ub);
    [~,~,Xe,S,Ke] = fe_eval(S, X); n = numel(Ke); if n == 0, break; end
    X(1:n,:) = Xe; K(1:n) = Ke;
end
R = run_result(S);
end
