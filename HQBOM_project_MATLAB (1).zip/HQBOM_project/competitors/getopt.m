function v = getopt(o, name, default)
%GETOPT  Return o.(name) if present, otherwise DEFAULT.
if isfield(o, name), v = o.(name); else, v = default; end
end
