function R = alg_coa(prob, maxFE, o)
%ALG_COA  Coati Optimization Algorithm (Dehghani et al. 2023), N = 50.
%   Phase 1 (hunting/attacking the iguana) and phase 2 (escaping from
%   predators), each with greedy replacement; the fitness of the fallen
%   iguana position is evaluated as in the reference code.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
t = 0; h = floor(N/2);
while S.fe < S.maxFE
    t = t + 1;
    Ig = S.bestX;
    % ---- phase 1, first half: attack iguana on the tree
    I = randi(2, h, D);
    X1 = X(1:h,:) + rand(h,D).*(Ig - I.*X(1:h,:));
    % ---- phase 1, second half: iguana falls to a random place
    m = N - h;
    IgG = lb + rand(m,D).*rg;
    [~,~,IgG,S,KG] = fe_eval(S, IgG); if numel(KG) < m, break; end
    I2 = randi(2, m, D); Xs = X(h+1:N,:);
    better = KG < K(h+1:N);
    X2 = Xs + rand(m,D).*(Xs - IgG);
    X2b = Xs + rand(m,D).*(IgG - I2.*Xs);
    X2(better,:) = X2b(better,:);
    Xn = min(max([X1; X2], lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    bb = Kn <= K(1:n); idx = find(bb); X(idx,:) = Xn(bb,:); K(idx) = Kn(bb);
    % ---- phase 2: escape from predators (local search)
    LOl = lb/t; HIl = ub/t;
    Xn = X + (1 - 2*rand(N,D)).*(LOl + rand(N,D).*(HIl - LOl));
    Xn = min(max(Xn, lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    bb = Kn <= K(1:n); idx = find(bb); X(idx,:) = Xn(bb,:); K(idx) = Kn(bb);
end
R = run_result(S);
end
