function R = alg_gto(prob, maxFE, o)
%ALG_GTO  Artificial Gorilla Troops Optimizer (Abdollahzadeh et al. 2021),
%   N = 50, p = 0.03, beta = 3, w = 0.8; two greedy phases per iteration.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
p = 0.03; beta = 3; w = 0.8;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/(2*N))); t = 0;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    F = cos(2*rand) + 1; C = F*(1 - tt/T); L = C*(2*rand - 1);
    % ---- exploration
    GX = zeros(N,D);
    r = rand(N,1); r2 = rand(N,1);
    Z = (2*rand(N,D) - 1)*C;
    Xr = X(randi(N,N,1),:); Xr2 = X(randi(N,N,1),:);
    a = r < p; b = ~a & r2 >= 0.5; c = ~a & ~b;
    G1 = rg.*rand(N,D) + lb;
    G2 = (rand(N,1) - C).*Xr + L*(Z.*X);
    G3 = X - L*(L*(X - Xr2) + rand(N,1).*(X - Xr2));
    GX(a,:) = G1(a,:); GX(b,:) = G2(b,:); GX(c,:) = G3(c,:);
    GX = min(max(GX, lb), ub);
    [~,~,GX,S,Kg] = fe_eval(S, GX); n = numel(Kg); if n == 0, break; end
    bb = Kg <= K(1:n); idx = find(bb); X(idx,:) = GX(bb,:); K(idx) = Kg(bb);
    % ---- exploitation
    Xs = S.bestX;
    if C >= w
        g = 2^L;
        M = (abs(mean(X,1)).^g).^(1/g);
        GX = L*M.*(X - Xs) + X;
    else
        Q = 2*rand(N,1) - 1;
        E = randn(N,D); sc = rand(N,1) < 0.5;
        Es = repmat(randn(N,1),1,D); E(sc,:) = Es(sc,:);
        A = beta*E;
        GX = Xs - (Xs.*Q - X.*Q).*A;
    end
    GX = min(max(GX, lb), ub);
    [~,~,GX,S,Kg] = fe_eval(S, GX); n = numel(Kg); if n == 0, break; end
    bb = Kg <= K(1:n); idx = find(bb); X(idx,:) = GX(bb,:); K(idx) = Kg(bb);
end
R = run_result(S);
end
