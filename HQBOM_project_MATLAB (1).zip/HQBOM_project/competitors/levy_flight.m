function L = levy_flight(n, d, beta)
%LEVY_FLIGHT  Mantegna's algorithm for Levy-distributed steps (n-by-d).
if nargin < 3, beta = 1.5; end
sigma = (gamma(1+beta)*sin(pi*beta/2) / (gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
L = 0.01 * (randn(n,d)*sigma) ./ abs(randn(n,d)).^(1/beta);
end
