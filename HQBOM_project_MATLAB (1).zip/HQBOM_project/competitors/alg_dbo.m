function R = alg_dbo(prob, maxFE, o)
%ALG_DBO  Dung Beetle Optimizer (Xue & Shen 2022), N = 50 split into
%   ball-rolling (20%), brood-ball (20%), small (24%) and thief (36%)
%   beetles; k = 0.1, b = 0.3, S = 0.5; personal-best bookkeeping as in
%   the reference code.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
nR = round(0.2*N); nB = round(0.2*N); nS = round(0.24*N);
iR = 1:nR; iB = nR+(1:nB); iS = nR+nB+(1:nS); iT = nR+nB+nS+1:N;
pX = X; pK = K; Xprev = X;
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    [~, iw] = max(K); Xw = X(iw,:);
    [~, il] = min(pK); Xl = pX(il,:);       % current local best
    Xg = S.bestX;                            % global best
    Rr = 1 - tt/T;
    Xn = pX;
    % ball rolling / dancing
    for i = iR
        if rand < 0.9
            a = 1; if rand < 0.1, a = -1; end
            Xn(i,:) = pX(i,:) + 0.3*abs(pX(i,:) - Xw) + a*0.1*Xprev(i,:);
        else
            th = randi(180)*pi/180;
            if abs(th - pi/2) > 1e-12 && th < pi
                Xn(i,:) = pX(i,:) + tan(th)*abs(pX(i,:) - Xprev(i,:));
            end
        end
    end
    % brood balls
    Lb = max(Xl*(1 - Rr), lb); Ub = min(Xl*(1 + Rr), ub);
    nb = numel(iB);
    Xn(iB,:) = Xl + rand(nb,D).*(pX(iB,:) - Lb) + rand(nb,D).*(pX(iB,:) - Ub);
    Xn(iB,:) = min(max(Xn(iB,:), Lb), Ub);
    % small dung beetles
    Lbb = max(Xg*(1 - Rr), lb); Ubb = min(Xg*(1 + Rr), ub);
    ns = numel(iS);
    Xn(iS,:) = pX(iS,:) + randn(ns,1).*(pX(iS,:) - Lbb) + rand(ns,D).*(pX(iS,:) - Ubb);
    % thieves
    nt = numel(iT);
    Xn(iT,:) = Xg + 0.5*randn(nt,D).*(abs(pX(iT,:) - Xl) + abs(pX(iT,:) - Xg));
    Xn = min(max(Xn, lb), ub);
    Xprev = X;
    [~,~,Xe,S,Ke] = fe_eval(S, Xn); n = numel(Ke); if n == 0, break; end
    X(1:n,:) = Xe; K(1:n) = Ke;
    bb = K <= pK; pX(bb,:) = X(bb,:); pK(bb) = K(bb);
end
R = run_result(S);
end
