function R = alg_so(prob, maxFE, o)
%ALG_SO  Snake Optimizer (Hashim & Hussien 2022), N = 50 (25 males and
%   25 females), c1 = 0.5, c2 = 0.05, c3 = 2, Q-threshold 0.25,
%   temperature threshold 0.6; greedy replacement in each sub-swarm.
%   Fitness ratios exp(-f_a/f_b) use non-negative shifted keys.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
c1 = 0.5; c2 = 0.05; c3 = 2;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
Nm = floor(N/2); Nf = N - Nm;
Xm = X(1:Nm,:); Km = K(1:Nm); Xf = X(Nm+1:end,:); Kf = K(Nm+1:end);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    Temp = exp(-tt/T); Q = c1*exp((tt - T)/T); Q = min(Q, 1);
    [kbm, im] = min(Km); [kbf, iF] = min(Kf);
    Xbm = Xm(im,:); Xbf = Xf(iF,:); Xfood = S.bestX;
    sh = min([0; Km; Kf]);
    km = Km - sh + 1e-300; kf = Kf - sh + 1e-300;
    flag = @(n) 2*(rand(n,1) < 0.5) - 1;
    if Q < 0.25
        rm = randi(Nm, Nm, 1); Am = exp(-km(rm) ./ km);
        Xnm = Xm(rm,:) + flag(Nm)*c2.*Am.*(rg.*rand(Nm,D) + lb);
        rf = randi(Nf, Nf, 1); Af = exp(-kf(rf) ./ kf);
        Xnf = Xf(rf,:) + flag(Nf)*c2.*Af.*(rg.*rand(Nf,D) + lb);
    elseif Temp > 0.6
        Xnm = Xfood + flag(Nm)*c3*Temp.*rand(Nm,D).*(Xfood - Xm);
        Xnf = Xfood + flag(Nf)*c3*Temp.*rand(Nf,D).*(Xfood - Xf);
    elseif rand > 0.6
        FM = exp(-(kbf - sh + 1e-300) ./ km);
        FF = exp(-(kbm - sh + 1e-300) ./ kf);
        Xnm = Xm + c3*FM.*rand(Nm,D).*(Q*Xbf - Xm);
        Xnf = Xf + c3*FF.*rand(Nf,D).*(Q*Xbm - Xf);
    else
        n = min(Nm, Nf);
        Mm = exp(-kf(1:n) ./ km(1:n)); Mf = exp(-km(1:n) ./ kf(1:n));
        Xnm = Xm; Xnf = Xf;
        Xnm(1:n,:) = Xm(1:n,:) + flag(n)*c3.*Mm.*rand(n,D).*(Q*Xf(1:n,:) - Xm(1:n,:));
        Xnf(1:n,:) = Xf(1:n,:) + flag(n)*c3.*Mf.*rand(n,D).*(Q*Xm(1:n,:) - Xf(1:n,:));
        if rand < 0.5      % egg hatching: replace the worst male and female
            [~, wm] = max(Km); [~, wf] = max(Kf);
            Xnm(wm,:) = lb + rand(1,D).*rg; Xnf(wf,:) = lb + rand(1,D).*rg;
        end
    end
    Xn = min(max([Xnm; Xnf], lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    Kall = [Km; Kf]; Xall = [Xm; Xf];
    bb = Kn <= Kall(1:n); idx = find(bb); Xall(idx,:) = Xn(bb,:); Kall(idx) = Kn(bb);
    Xm = Xall(1:Nm,:); Km = Kall(1:Nm); Xf = Xall(Nm+1:end,:); Kf = Kall(Nm+1:end);
end
R = run_result(S);
end
