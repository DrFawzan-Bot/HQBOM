function R = alg_pso(prob, maxFE, o)
%ALG_PSO  Particle Swarm Optimisation (Kennedy & Eberhart 1995) with
%   linearly decreasing inertia w: 0.9 -> 0.4, c1 = c2 = 2,
%   |v| <= 0.2*(ub-lb), N = 50, global-best topology.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; vmax = 0.2*(ub-lb);
X = lb + rand(N,D).*(ub-lb); Vel = zeros(N,D);
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
P = X; KP = K;
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; w = 0.9 - 0.5*min(t/T,1);
    [~, g] = min(KP);
    Vel = w*Vel + 2*rand(N,D).*(P - X) + 2*rand(N,D).*(P(g,:) - X);
    Vel = min(max(Vel,-vmax),vmax);
    X = min(max(X + Vel, lb), ub);
    [~,~,Xe,S,K] = fe_eval(S, X); n = numel(K); if n == 0, break; end
    X(1:n,:) = Xe;
    b = K <= KP(1:n); idx = find(b); P(idx,:) = X(idx,:); KP(idx) = K(b);
end
R = run_result(S);
end
