function R = shade_family(prob, maxFE, variant)
%SHADE_FAMILY  L-SHADE (Tanabe & Fukunaga 2014), iL-SHADE (Brest et al.
%   2016) and jSO (Brest et al. 2017) - success-history adaptive DE with
%   linear population size reduction, current-to-pbest/1 (jSO: weighted
%   current-to-pbest-w/1) mutation, binomial crossover and an external
%   archive. Parameters follow the original papers:
%                 NPinit           H   MF0  MCR0  p             |A|/NP
%   'lshade'      18*D             6   0.5  0.5   0.11          2.6
%   'ilshade'     12*D             6   0.5  0.8   0.2 -> 0.1    1.0
%   'jso'         25*ln(D)*sqrt(D) 5   0.3  0.8   0.25 -> 0.125 1.0
%   NPmin = 4. Bound handling: midpoint between parent and violated bound.
D = prob.D; lb = prob.lb; ub = prob.ub;
switch variant
    case 'lshade',  NP0 = 18*D; H = 6; MF0 = 0.5; MCR0 = 0.5; arc = 2.6;
    case 'ilshade', NP0 = 12*D; H = 6; MF0 = 0.5; MCR0 = 0.8; arc = 1.0;
    case 'jso',     NP0 = round(25*log(D)*sqrt(D)); H = 5; MF0 = 0.3; MCR0 = 0.8; arc = 1.0;
end
NP0 = max(NP0, 10); NPmin = 4;
S = fe_init(prob, maxFE);
X = lb + rand(NP0,D).*(ub - lb);
[~,~,X,S,K] = fe_eval(S, X); NP = size(X,1);
MF = MF0*ones(H,1); MCR = MCR0*ones(H,1); kk = 1;
if ~strcmp(variant,'lshade'), MF(H) = 0.9; MCR(H) = 0.9; end
A = zeros(0,D);
while S.fe < S.maxFE
    prog = S.fe / S.maxFE;
    switch variant
        case 'lshade',  pbest = 0.11;
        case 'ilshade', pbest = 0.2 - 0.1*prog;
        case 'jso',     pbest = 0.25 - 0.125*prog;
    end
    ri = randi(H, NP, 1);
    mcr = MCR(ri); CR = mcr + 0.1*randn(NP,1);
    CR(mcr < 0) = 0; CR = min(max(CR,0),1);
    mf = MF(ri); F = mf + 0.1*tan(pi*(rand(NP,1) - 0.5));
    while any(F <= 0)
        bad = F <= 0; F(bad) = mf(bad) + 0.1*tan(pi*(rand(nnz(bad),1) - 0.5));
    end
    F = min(F, 1);
    if strcmp(variant,'ilshade')
        if prog < 0.25, CR = max(CR,0.5); elseif prog < 0.5, CR = max(CR,0.25); end
        if prog < 0.25, F = min(F,0.7); elseif prog < 0.5, F = min(F,0.8);
        elseif prog < 0.75, F = min(F,0.9); end
    elseif strcmp(variant,'jso')
        if prog < 0.25, CR = max(CR,0.7); elseif prog < 0.5, CR = max(CR,0.6); end
        if prog < 0.6, F = min(F,0.7); end
    end
    Fw = F;
    if strcmp(variant,'jso')
        if prog < 0.2, Fw = 0.7*F; elseif prog < 0.4, Fw = 0.8*F; else, Fw = 1.2*F; end
    end
    [~, srt] = sort(K);
    np = max(2, round(pbest*NP));
    pb = srt(randi(np, NP, 1));
    r1 = randi(NP, NP, 1);
    bad = r1 == (1:NP)';
    while any(bad), r1(bad) = randi(NP, nnz(bad), 1); bad = r1 == (1:NP)'; end
    PA = [X; A]; nPA = size(PA,1);
    r2 = randi(nPA, NP, 1);
    bad = r2 == (1:NP)' | r2 == r1;
    while any(bad), r2(bad) = randi(nPA, nnz(bad), 1); bad = r2 == (1:NP)' | r2 == r1; end
    V = X + Fw.*(X(pb,:) - X) + F.*(X(r1,:) - PA(r2,:));
    lo = V < lb; LBm = repmat(lb,NP,1); V(lo) = (LBm(lo) + X(lo))/2;
    hi = V > ub; UBm = repmat(ub,NP,1); V(hi) = (UBm(hi) + X(hi))/2;
    mask = rand(NP,D) <= CR; jr = randi(D,NP,1);
    mask(sub2ind([NP D],(1:NP)',jr)) = true;
    U = X; U(mask) = V(mask);
    [~,~,U,S,Ku] = fe_eval(S, U); n = numel(Ku); if n == 0, break; end
    idx = (1:n)';
    imp = Ku < K(idx); eqb = Ku <= K(idx);
    dK = abs(K(imp) - Ku(imp));
    A = [A; X(imp,:)];
    SF = F(imp); SCR = CR(imp);
    X(eqb,:) = U(eqb,:); K(eqb) = Ku(eqb);
    % memory update
    if ~isempty(SF)
        if all(isinf(dK)) || sum(dK) == 0, wt = ones(size(dK))/numel(dK);
        else, dK(isinf(dK)) = max(dK(~isinf(dK))); wt = dK/sum(dK); end
        newF = sum(wt.*SF.^2)/sum(wt.*SF);
        if max(SCR) == 0 || MCR(kk) < 0, newCR = -1;
        else, newCR = sum(wt.*SCR.^2)/sum(wt.*SCR); end
        if strcmp(variant,'lshade')
            MF(kk) = newF; MCR(kk) = newCR;
        else
            MF(kk) = (MF(kk) + newF)/2;
            if newCR < 0, MCR(kk) = -1; else, MCR(kk) = (max(MCR(kk),0) + newCR)/2; end
        end
        kk = kk + 1;
        if strcmp(variant,'lshade'), if kk > H, kk = 1; end
        else, if kk > H-1, kk = 1; end
        end
    end
    % linear population size reduction
    NPn = round((NPmin - NP0)/S.maxFE*S.fe + NP0);
    if NPn < NP
        [~, srt] = sort(K); keep = srt(1:max(NPn,NPmin));
        X = X(keep,:); K = K(keep); NP = size(X,1);
    end
    amax = round(arc*NP);
    if size(A,1) > amax, A = A(randperm(size(A,1), amax),:); end
end
R = run_result(S);
end
