function R = alg_avoa(prob, maxFE, o)
%ALG_AVOA  African Vultures Optimization Algorithm (Abdollahzadeh et al.
%   2021), N = 50, p1 = 0.6, p2 = 0.4, p3 = 0.6, L1 = 0.8, L2 = 0.2,
%   w = 2.5; positions are replaced each iteration (reference code).
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
p1 = 0.6; p2 = 0.4; p3 = 0.6; L1 = 0.8; w = 2.5;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    [~, s] = sort(K); B1 = X(s(1),:); B2 = X(s(min(2,N)),:);
    useB1 = rand(N,1) < L1;
    Rv = repmat(B2, N, 1); Rv(useB1,:) = repmat(B1, nnz(useB1), 1);
    z = 2*rand(N,1) - 1; h = 4*rand(N,1) - 2;
    tf = h .* (sin(pi/2*tt/T)^w + cos(pi/2*tt/T) - 1);
    F = (2*rand(N,1) + 1) .* z .* (1 - tt/T) + tf;
    rd = rand(N,1); r2 = rand(N,1);
    C1 = Rv - abs(2*rand(N,1).*Rv - X) .* F;
    C2 = Rv - F + rand(N,1).*(rg.*rand(N,D) + lb);
    C3 = abs(2*rand(N,1).*Rv - X) .* (F + rand(N,1)) - (Rv - X);
    S1 = Rv .* (rand(N,1).*X/(2*pi)) .* cos(X);
    S2 = Rv .* (rand(N,1).*X/(2*pi)) .* sin(X);
    C4 = Rv - (S1 + S2);
    A1 = B1 - (B1.*X) ./ (B1 - X.^2 + eps) .* F;
    A2 = B2 - (B2.*X) ./ (B2 - X.^2 + eps) .* F;
    C5 = (A1 + A2) / 2;
    C6 = Rv - abs(Rv - X) .* F .* levy_flight(N, D);
    aF = abs(F);
    Xn = C6;
    m = aF >= 1 & p1 >= rd;            Xn(m,:) = C1(m,:);
    m = aF >= 1 & p1 <  rd;            Xn(m,:) = C2(m,:);
    m = aF < 1 & aF >= 0.5 & p2 >= r2; Xn(m,:) = C3(m,:);
    m = aF < 1 & aF >= 0.5 & p2 <  r2; Xn(m,:) = C4(m,:);
    m = aF < 0.5 & p3 >= rd;           Xn(m,:) = C5(m,:);
    X = min(max(Xn, lb), ub);
    [~,~,Xe,S,Ke] = fe_eval(S, X); n = numel(Ke); if n == 0, break; end
    X(1:n,:) = Xe; K(1:n) = Ke;
end
R = run_result(S);
end
