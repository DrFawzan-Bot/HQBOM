function R = alg_sca(prob, maxFE, o)
%ALG_SCA  Sine Cosine Algorithm (Mirjalili 2016), N = 50, a = 2.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub;
X = lb + rand(N,D).*(ub-lb);
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; r1 = 2 - 2*min(t/T,1);
    Xb = S.bestX;
    r2 = 2*pi*rand(N,D); r3 = 2*rand(N,D); r4 = rand(N,D);
    St = r1*sin(r2).*abs(r3.*Xb - X); Ct = r1*cos(r2).*abs(r3.*Xb - X);
    Xn = X + St; c = r4 >= 0.5; Xn(c) = X(c) + Ct(c);
    X = min(max(Xn, lb), ub);
    [~,~,Xe,S,Ke] = fe_eval(S, X); n = numel(Ke); if n == 0, break; end
    X(1:n,:) = Xe; K(1:n) = Ke;
end
R = run_result(S);
end
