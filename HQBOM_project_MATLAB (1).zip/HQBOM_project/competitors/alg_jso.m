function R = alg_jso(prob, maxFE, o)
%ALG_JSO  Wrapper for shade_family(..., 'jso').
R = shade_family(prob, maxFE, 'jso');
end
