function R = alg_hgs(prob, maxFE, o)
%ALG_HGS  Hunger Games Search (Yang et al. 2021), N = 50, l = 0.08,
%   LH = 10000; positions replaced each iteration (reference code).
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
l = 0.08; LH = 10000;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
H = zeros(N,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    BF = min(K); WF = max(K); Xb = S.bestX; Kb = S.bestK;
    % hunger update
    TH = (K - BF) / (WF - BF + eps) .* rand(N,1) * 2 * mean(rg);
    Hn = TH; small = TH < LH; Hn(small) = LH * (1 + rand(nnz(small),1));
    H = H + Hn; H(K == BF) = 0;
    sH = sum(H);
    shrink = 2*(1 - tt/T);
    E = sech(min(abs(K - Kb), 700));
    W1 = ones(N,D); c = rand(N,D) < l;
    W1H = (H*N/(sH + eps)) .* rand(N,D); W1(c) = W1H(c);
    W2 = (1 - exp(-abs(H - sH))) .* rand(N,D) * 2;
    Rr = 2*shrink*rand(N,D) - shrink;
    r1 = rand(N,1) < l; r2 = rand(N,D) > E;
    A = W1.*Xb + Rr.*W2.*abs(Xb - X);
    Bm = W1.*Xb - Rr.*W2.*abs(Xb - X);
    Xn = Bm; Xn(r2) = A(r2);
    Xg = X .* (1 + randn(N,1));
    Xn(r1,:) = Xg(r1,:);
    X = min(max(Xn, lb), ub);
    [~,~,Xe,S,Ke] = fe_eval(S, X); n = numel(Ke); if n == 0, break; end
    X(1:n,:) = Xe; K(1:n) = Ke;
end
R = run_result(S);
end
