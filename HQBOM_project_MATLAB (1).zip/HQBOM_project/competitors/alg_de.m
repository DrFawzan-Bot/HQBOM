function R = alg_de(prob, maxFE, o)
%ALG_DE  Differential Evolution DE/rand/1/bin (Storn & Price 1997).
%   N = 100, F = 0.5, CR = 0.9; one-to-one greedy selection (Deb key).
if nargin < 3, o = struct(); end
N = getopt(o,'N',100); F = getopt(o,'F',0.5); CR = getopt(o,'CR',0.9);
S = fe_init(prob, maxFE); D = prob.D; lb = prob.lb; ub = prob.ub;
X = lb + rand(N,D).*(ub-lb);
[~,~,X,S,K] = fe_eval(S, X);
while S.fe < S.maxFE
    N = size(X,1);
    r = rand_distinct(N, 3);
    V = X(r(:,1),:) + F*(X(r(:,2),:) - X(r(:,3),:));
    mask = rand(N,D) < CR; jr = randi(D,N,1);
    mask(sub2ind([N D],(1:N)',jr)) = true;
    U = X; U(mask) = V(mask);
    U = min(max(U,lb),ub);
    [~,~,U,S,Ku] = fe_eval(S, U);
    n = numel(Ku); if n == 0, break; end
    b = Ku <= K(1:n); X(b,:) = U(b,:); K(b) = Ku(b);
end
R = run_result(S);
end
