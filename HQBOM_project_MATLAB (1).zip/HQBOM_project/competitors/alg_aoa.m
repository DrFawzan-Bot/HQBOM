function R = alg_aoa(prob, maxFE, o)
%ALG_AOA  Arithmetic Optimization Algorithm (Abualigah et al. 2021).
%   N = 50, MOA in [0.2, 1], sensitivity alpha = 5, mu = 0.499; greedy
%   replacement as in the authors' reference code.
if nargin < 3, o = struct(); end
N = getopt(o,'N',50); S = fe_init(prob, maxFE);
D = prob.D; lb = prob.lb; ub = prob.ub; rg = ub - lb;
mu = 0.499; al = 5; MOAmin = 0.2; MOAmax = 1;
X = lb + rand(N,D).*rg;
[~,~,X,S,K] = fe_eval(S, X); N = size(X,1);
T = max(1, floor((maxFE - N)/N)); t = 0;
while S.fe < S.maxFE
    t = t + 1; tt = min(t,T);
    MOA = MOAmin + tt*(MOAmax - MOAmin)/T;
    MOP = 1 - (tt^(1/al)) / (T^(1/al));
    Xb = S.bestX; e = eps;
    r1 = rand(N,D); r2 = rand(N,D); r3 = rand(N,D);
    base = rg*mu + lb;
    Xn = zeros(N,D);
    ex = r1 > MOA;
    c1 = ex & r2 > 0.5;  c2 = ex & r2 <= 0.5;
    c3 = ~ex & r3 > 0.5; c4 = ~ex & r3 <= 0.5;
    B = repmat(Xb, N, 1); BB = repmat(base, N, 1);
    Xn(c1) = B(c1) ./ (MOP + e) .* BB(c1);
    Xn(c2) = B(c2) .* MOP .* BB(c2);
    Xn(c3) = B(c3) - MOP .* BB(c3);
    Xn(c4) = B(c4) + MOP .* BB(c4);
    Xn = min(max(Xn, lb), ub);
    [~,~,Xn,S,Kn] = fe_eval(S, Xn); n = numel(Kn); if n == 0, break; end
    b = Kn <= K(1:n); idx = find(b); X(idx,:) = Xn(b,:); K(idx) = Kn(b);
end
R = run_result(S);
end
