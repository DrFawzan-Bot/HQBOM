%MAIN_RUN_ALL  Reproduce every number, table and figure of the paper
%   "Hybrid Pattern Search-Quantum-Based Optimisation Methods (HQBOM-I and
%   HQBOM-II) for Engineering Optimisation Problems".
%
%   Steps (each step can be run on its own; finished results are reused):
%     1. compile the official CEC2017 C code (once)
%     2. CEC2017 experiment, D = 30, 29 functions, 22 algorithms, 30 runs
%     3. engineering experiment, 7 problems, 22 algorithms, 30 runs
%     4. statistics + CSV/Excel tables
%     5. convergence figures
%   Runtime: about 3-5 s per CEC2017 run on one core (19,140 runs), i.e.
%   run_cec2017 may be split over several MATLAB sessions, e.g.
%   run_cec2017(1:11) in one and run_cec2017(12:22) in another.
here = fileparts(mfilename('fullpath'));
addpath(fullfile(here, 'experiments')); setup_paths;
% 1 ---------------------------------------------------------------
if exist('cec17_func', 'file') ~= 3
    old = cd(fullfile(here, 'cec2017'));
    mex cec17_func.cpp            % in GNU Octave: mkoctfile --mex cec17_func.cpp
    cd(old);
end
% 2 ---------------------------------------------------------------
run_cec2017();
% 3 ---------------------------------------------------------------
run_engineering();
% 4 ---------------------------------------------------------------
analyze_cec2017();
analyze_engineering();
% 5 ---------------------------------------------------------------
plot_convergence();
