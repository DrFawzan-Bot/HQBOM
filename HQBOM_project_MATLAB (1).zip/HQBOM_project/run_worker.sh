#!/bin/bash
# Resumable experiment workers (completed result files are skipped).
#   ./run_worker.sh A   engineering study, then CEC2017 algorithms 1 3 5 ... 21
#   ./run_worker.sh B   CEC2017 algorithms 2 4 ... 22
cd "$(dirname "$0")/experiments"
case "$1" in
  A) octave-cli -q --eval "setup_paths; run_engineering(); run_cec2017([1 3 5 7 9 11 13 15 17 21]);" ;;
  B) octave-cli -q --eval "setup_paths; run_cec2017([2 4 6 8 10 12 14 16 18 19 20 22]);" ;;
esac
