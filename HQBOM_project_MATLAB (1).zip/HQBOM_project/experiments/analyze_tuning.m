function analyze_tuning()
%ANALYZE_TUNING  Friedman ranking of the tuning configurations (Table 5).
%   Each family (HQBOM-I, HQBOM-II) is ranked separately on the mean
%   error of the 29 CEC2017 functions at D = 10. Writes
%   results/tuning/tuning_ranks.csv.
C = tuning_configs(); root = fullfile(project_root(), 'results', 'tuning');
M = []; names = {};
for c = 1:numel(C)
    L = load(fullfile(root, sprintf('cfg%02d.mat', c)));
    M(:, c) = mean(L.err, 2); names{c} = C(c).name; %#ok<AGROW>
end
fam = {find(strncmp(names, 'HQBOM-I ', 8)), find(strncmp(names, 'HQBOM-II', 8))};
rows = {};
for f = 1:2
    idx = fam{f}; Fr = friedman_test(M(:, idx));
    for j = 1:numel(idx)
        rows(end+1, :) = {names{idx(j)}, Fr.avgRank(j), mean(log10(M(:, idx(j)) + 1e-8)), Fr.p_chi2}; %#ok<AGROW>
    end
end
write_csv(fullfile(root, 'tuning_ranks.csv'), {'Configuration', 'Average_rank_within_family', 'Mean_log10_mean_error', 'Friedman_p_family'}, rows);
end
