function tune_hqbom(cfgIdx, nRuns)
%TUNE_HQBOM  Parameter selection for HQBOM-I and HQBOM-II (Section 6.4).
%   Tuning set: CEC2017 F1, F3-F30 in dimension D = 10 (FEmax = 100 000,
%   NRUNS runs, default 10, seeds rng(seed_base('tune') + 1000*f + r)).
%   This set is disjoint from the test sets (D = 30, engineering
%   problems). Results: results/tuning/*.mat; summarised by
%   analyze_tuning.m (Friedman ranks of the configurations).
C = tuning_configs();
if nargin < 1 || isempty(cfgIdx), cfgIdx = 1:numel(C); end
if nargin < 2, nRuns = 10; end
D = 10; maxFE = 10000 * D; fns = [1 3:30];
out = fullfile(project_root(), 'results', 'tuning');
if ~exist(out, 'dir'), [~, ~] = mkdir(out); end   % tolerant to parallel workers
for c = cfgIdx
    fn = fullfile(out, sprintf('cfg%02d.mat', c));
    if exist(fn, 'file'), continue; end
    err = zeros(numel(fns), nRuns);
    for i = 1:numel(fns)
        p = cec2017_problem(fns(i), D);
        for r = 1:nRuns
            rng(seed_base('tune') + 1000*fns(i) + r);
            Rr = C(c).fun(p, maxFE);
            e = Rr.bestF; if e < 1e-8, e = 0; end
            err(i, r) = e;
        end
    end
    name = C(c).name; %#ok<NASGU>
    save(fn, '-v7', 'name', 'err', 'fns');
    fprintf('%-28s mean log10 err = %.3f\n', C(c).name, mean(mean(log10(err + 1e-8))));
end
end
