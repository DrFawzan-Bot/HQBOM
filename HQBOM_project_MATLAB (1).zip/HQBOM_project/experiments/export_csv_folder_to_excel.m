function export_csv_folder_to_excel(folder, xlsxFile)
%EXPORT_CSV_FOLDER_TO_EXCEL  (MATLAB) Put every CSV of FOLDER into one
%   sheet of XLSXFILE (sheet name = file name, truncated to 31 chars).
d = dir(fullfile(folder, '*.csv'));
if exist(xlsxFile, 'file'), delete(xlsxFile); end
for i = 1:numel(d)
    T = readtable(fullfile(folder, d(i).name), 'TextType', 'char');
    sh = strrep(d(i).name, '.csv', ''); sh = sh(1:min(31, numel(sh)));
    writetable(T, xlsxFile, 'Sheet', sh);
end
end
