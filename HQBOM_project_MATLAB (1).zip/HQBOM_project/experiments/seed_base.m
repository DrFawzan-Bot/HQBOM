function b = seed_base(kind)
%SEED_BASE  Offset of the random-number seeds of the experiments.
%   Revision 2 (this release) uses new seeds, independent of those of
%   revision 1 (which used offset 0):
%     CEC2017      run r of function f : rng(seed_base('cec') + 1000*f + r)
%     engineering  run r of problem q  : rng(seed_base('eng') + 5000*q + r)
%     tuning (D = 10)                  : rng(seed_base('tune') + 1000*f + r)
switch kind
    case 'cec',  b = 7000000;
    case 'eng',  b = 9000000;
    case 'tune', b = 3000000;
    otherwise, error('unknown seed kind');
end
end
