function A = algorithm_registry()
%ALGORITHM_REGISTRY  Names, handles and groups of all 22 optimisers.
%   Group: 'proposed' (HQBOM-I, HQBOM-II), 'ablation' (QBOM, PS),
%   'classical', 'recent' (2021-2023), 'cec' (CEC competition lineage).
A = struct('name', {}, 'fun', {}, 'group', {}, 'ref', {});
A(end+1) = s('HQBOM-I',   @hqbom1,        'proposed', 'this work');
A(end+1) = s('HQBOM-II',  @hqbom2,        'proposed', 'this work');
A(end+1) = s('QBOM',      @qbom,          'ablation', 'Alfares 2004; Al-Othman et al. 2015');
A(end+1) = s('PS',        @pattern_search,'ablation', 'Torczon 1997 (GPS)');
A(end+1) = s('DE',        @alg_de,        'classical','Storn & Price 1997');
A(end+1) = s('PSO',       @alg_pso,       'classical','Kennedy & Eberhart 1995');
A(end+1) = s('GWO',       @alg_gwo,       'classical','Mirjalili et al. 2014');
A(end+1) = s('WOA',       @alg_woa,       'classical','Mirjalili & Lewis 2016');
A(end+1) = s('SCA',       @alg_sca,       'classical','Mirjalili 2016');
A(end+1) = s('AOA',       @alg_aoa,       'recent',   'Abualigah et al. 2021');
A(end+1) = s('AO',        @alg_ao,        'recent',   'Abualigah et al. 2021');
A(end+1) = s('RSA',       @alg_rsa,       'recent',   'Abualigah et al. 2022');
A(end+1) = s('AVOA',      @alg_avoa,      'recent',   'Abdollahzadeh et al. 2021');
A(end+1) = s('HBA',       @alg_hba,       'recent',   'Hashim et al. 2022');
A(end+1) = s('HGS',       @alg_hgs,       'recent',   'Yang et al. 2021');
A(end+1) = s('SO',        @alg_so,        'recent',   'Hashim & Hussien 2022');
A(end+1) = s('GTO',       @alg_gto,       'recent',   'Abdollahzadeh et al. 2021');
A(end+1) = s('COA',       @alg_coa,       'recent',   'Dehghani et al. 2023');
A(end+1) = s('DBO',       @alg_dbo,       'recent',   'Xue & Shen 2022');
A(end+1) = s('L-SHADE',   @alg_lshade,    'cec',      'Tanabe & Fukunaga 2014');
A(end+1) = s('iL-SHADE',  @alg_ilshade,   'cec',      'Brest et al. 2016');
A(end+1) = s('jSO',       @alg_jso,       'cec',      'Brest et al. 2017');
end
function x = s(n, f, g, r)
x = struct('name', n, 'fun', f, 'group', g, 'ref', r);
end
