function P = engineering_registry()
%ENGINEERING_REGISTRY  Engineering problems of Section 6.2, the common FE
%   budget and the best-known feasible value used for the success rate.
P = struct('make', {}, 'maxFE', {}, 'tag', {}, 'sense', {});
P(end+1) = s(@pressure_vessel, 20000, 'PV',    1);
P(end+1) = s(@spring_design,   20000, 'SPR',   1);
P(end+1) = s(@ic_engine,       20000, 'ICE',  -1);   % maximise power
P(end+1) = s(@speed_reducer,   20000, 'SRD',   1);
P(end+1) = s(@sced_2gen,       20000, 'SCED2', 1);
P(end+1) = s(@sced_7gen,       20000, 'SCED7', 1);
P(end+1) = s(@chped_5unit,     20000, 'CHPED', 1);
end
function x = s(m, fe, t, sg)
x = struct('make', m, 'maxFE', fe, 'tag', t, 'sense', sg);
end
