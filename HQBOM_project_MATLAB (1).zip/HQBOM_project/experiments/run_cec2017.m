function run_cec2017(algIdx, fns, nRuns, D)
%RUN_CEC2017  CEC2017 experiment (Section 6.1 of the paper).
%   RUN_CEC2017(ALGIDX, FNS, NRUNS, D) runs the algorithms ALGIDX (indices
%   into ALGORITHM_REGISTRY, default all) on functions FNS (default
%   [1 3:30]; F2 is excluded), NRUNS independent runs (default 30), in
%   dimension D (default 30), with FEmax = 10000*D.
%   Seeding protocol (common random numbers): run r of function f uses
%   rng(seed_base('cec') + 1000*f + r) for every algorithm.
%   One MAT file per (algorithm, function) is written to
%   results/cec2017/raw; existing files are skipped, so the experiment can
%   be resumed or split over several MATLAB sessions.
A = algorithm_registry();
if nargin < 1 || isempty(algIdx), algIdx = 1:numel(A); end
if nargin < 2 || isempty(fns),    fns = [1 3:30]; end
if nargin < 3 || isempty(nRuns),  nRuns = 30; end
if nargin < 4 || isempty(D),      D = 30; end
maxFE = 10000 * D;
out = fullfile(project_root(), 'results', 'cec2017', 'raw');
if ~exist(out, 'dir'), [~, ~] = mkdir(out); end   % tolerant to parallel workers
for a = algIdx
    for f = fns
        fn = fullfile(out, sprintf('%s_F%02d_D%d.mat', strrep(A(a).name,'-','_'), f, D));
        if exist(fn, 'file'), continue; end
        p = cec2017_problem(f, D);
        err = zeros(nRuns,1); feBest = zeros(nRuns,1); hist = zeros(nRuns,100);
        tRun = zeros(nRuns,1);
        for r = 1:nRuns
            rng(seed_base('cec') + 1000*f + r);
            t0 = tic;
            Rr = A(a).fun(p, maxFE);
            tRun(r) = toc(t0);
            e = Rr.bestF; if e < 1e-8, e = 0; end
            err(r) = e; feBest(r) = Rr.feAtBest; hist(r,:) = Rr.histF;
        end
        alg = A(a).name; func = f; %#ok<NASGU>
        save(fn, '-v7', 'alg', 'func', 'D', 'maxFE', 'err', 'feBest', 'hist', 'tRun');
        fprintf('%-9s F%02d  mean=%10.4e  std=%10.4e  (%.1f s/run)\n', ...
                A(a).name, f, mean(err), std(err), mean(tRun));
    end
end
end
