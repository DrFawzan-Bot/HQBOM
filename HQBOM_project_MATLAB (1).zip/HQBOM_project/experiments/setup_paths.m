function setup_paths()
%SETUP_PATHS  Add all project folders to the MATLAB/Octave path.
r = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(r,'core'), fullfile(r,'competitors'), fullfile(r,'problems'), ...
        fullfile(r,'cec2017'), fullfile(r,'stats'), fullfile(r,'experiments'));
end
