function analyze_box_ablation()
%ANALYZE_BOX_ABLATION  Effect of the QBOM local-search box (Section 9).
%   Compares QBOM, HQBOM-I and HQBOM-II with the symmetric box (main
%   results) and with the literal one-sided box of QBOM1.m
%   (results/ablation_onesided_box, produced with lsClip = 'original',
%   the same seeds, HQBOM-II with identical parameters and HQBOM-I with the
%   value rho = 0.3 selected by the tuning study for that box).
%   Wilcoxon rank-sum per function/problem, Holm-adjusted within each
%   algorithm and test set; '+' = symmetric box significantly better.
root = fullfile(project_root(), 'results');
algs = {'QBOM', 'HQBOM_I', 'HQBOM_II'};
rows = {};
sets = {'cec2017', [1 3:30]; 'engineering', 1:7};
P = engineering_registry();
for s = 1:2
    for a = 1:3
        pv = []; sg = []; lab = {};
        items = sets{s, 2};
        for k = items
            if s == 1
                f = sprintf('%s_F%02d_D30.mat', algs{a}, k); key = 'err';
                A = load(fullfile(root, 'cec2017', 'raw', f));
                B = load(fullfile(root, 'ablation_onesided_box', 'cec2017', f));
                xa = A.err; xb = B.err; lab{end+1} = sprintf('F%d', k); %#ok<AGROW>
            else
                f = sprintf('%s_%s.mat', algs{a}, P(k).tag);
                A = load(fullfile(root, 'engineering', 'raw', f));
                B = load(fullfile(root, 'ablation_onesided_box', 'engineering', f));
                xa = deb_key(A.f, A.v); xb = deb_key(B.f, B.v); lab{end+1} = P(k).tag; %#ok<AGROW>
            end
            pv(end+1) = ranksum_test(xa, xb); %#ok<AGROW>
            d = median(xb) - median(xa); if d == 0, d = mean(xb) - mean(xa); end
            sg(end+1) = sign(d); %#ok<AGROW>
        end
        pa = holm_adjust(pv);
        W = sum(pa < 0.05 & sg > 0); L = sum(pa < 0.05 & sg < 0); T = numel(pa) - W - L;
        rows(end+1, :) = {sets{s, 1}, strrep(algs{a}, '_', '-'), W, T, L}; %#ok<AGROW>
    end
end
write_csv(fullfile(root, 'ablation_onesided_box', 'box_ablation_wtl.csv'), ...
    {'Test_set', 'Algorithm', 'Symmetric_better', 'No_difference', 'One_sided_better'}, rows);
end
