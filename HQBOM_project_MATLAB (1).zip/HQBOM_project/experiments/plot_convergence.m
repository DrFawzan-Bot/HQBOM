function plot_convergence()
%PLOT_CONVERGENCE  Mean best-so-far error versus FEs (Figs. 5-6).
%   Plots the proposed hybrids, their components (QBOM, PS) and the three
%   best-ranked competitors for six representative functions.
A = algorithm_registry(); names = {A.name};
root = fullfile(project_root(), 'results', 'cec2017');
L = load(fullfile(root, 'cec_summary.mat')); T = L.T;
[~, ord] = sort(T.friedman.avgRank);
show = unique([find(ismember(names, {'HQBOM-I','HQBOM-II','QBOM','PS'})), ...
               setdiff(ord, find(ismember(names, {'HQBOM-I','HQBOM-II','QBOM','PS'})), 'stable')], 'stable');
show = show(1:min(7, numel(show)));
fns = [1 4 7 11 21 26];
fig = figure('Color', 'w', 'Position', [100 100 1100 650]);
ck = (1:100)/100 * 300000;
for s = 1:numel(fns)
    subplot(2, 3, s); hold on;
    for a = show
        R = load(fullfile(root, 'raw', sprintf('%s_F%02d_D30.mat', strrep(names{a},'-','_'), fns(s))));
        m = mean(R.hist, 1);
        semilogy(ck, max(m, 1e-8), 'LineWidth', 1.3);
    end
    set(gca, 'YScale', 'log'); grid on; box on;
    title(sprintf('F%d', fns(s))); xlabel('Function evaluations'); ylabel('Mean error');
end
legend(names(show), 'Location', 'southoutside', 'Orientation', 'horizontal');
print(fig, fullfile(root, 'convergence_cec2017.png'), '-dpng', '-r200');
end
