function T = analyze_cec2017(D)
%ANALYZE_CEC2017  Statistics for the CEC2017 experiment (Tables 4-7).
%   Reads results/cec2017/raw/*.mat and writes CSV tables (and, under
%   MATLAB, one Excel workbook) to results/cec2017:
%     cec_runs.csv          run-level final errors (30 runs x 29 x 22)
%     cec_descriptive.csv   best/worst/mean/median/std/IQR per alg/function
%     cec_friedman.csv      average Friedman ranks (computed on mean errors)
%     cec_holm.csv          Holm post-hoc test, control = best-ranked alg.
%     cec_holm_vs_HQBOM_I.csv  same with HQBOM-I as control
%     cec_ranksum_<alg>.csv Wilcoxon rank-sum p-values (HQBOM-I / HQBOM-II
%                           vs each algorithm), Holm-adjusted per comparison
%     cec_convergence.csv   mean best-so-far error at 100 FE checkpoints
if nargin < 1, D = 30; end
A = algorithm_registry(); k = numel(A); fns = [1 3:30]; nf = numel(fns);
root = fullfile(project_root(), 'results', 'cec2017');
raw  = fullfile(root, 'raw');
E = cell(nf, k); H = cell(nf, k); FB = cell(nf, k); TR = zeros(nf, k);
for a = 1:k
    for i = 1:nf
        fn = fullfile(raw, sprintf('%s_F%02d_D%d.mat', strrep(A(a).name,'-','_'), fns(i), D));
        L = load(fn);
        E{i,a} = L.err; H{i,a} = L.hist; FB{i,a} = L.feBest; TR(i,a) = mean(L.tRun);
    end
end
names = {A.name};
nr = numel(E{1,1});
% ---------------- run-level data -------------------------------------
rows = cell(nf*k*nr, 5); c = 0;
for a = 1:k, for i = 1:nf, for r = 1:nr
    c = c + 1; rows(c,:) = {names{a}, sprintf('F%d',fns(i)), r, E{i,a}(r), FB{i,a}(r)};
end, end, end
write_csv(fullfile(root,'cec_runs.csv'), {'Algorithm','Function','Run','Error','FE_at_best'}, rows);
% ---------------- descriptive statistics -----------------------------
Mmean = zeros(nf, k); Mstd = Mmean;
rows = cell(nf*k, 9); c = 0;
for a = 1:k
    for i = 1:nf
        s = desc_stats(E{i,a}); Mmean(i,a) = s.mean; Mstd(i,a) = s.std;
        c = c + 1;
        rows(c,:) = {names{a}, sprintf('F%d',fns(i)), s.best, s.worst, s.mean, s.median, s.std, s.iqr, TR(i,a)};
    end
end
write_csv(fullfile(root,'cec_descriptive.csv'), ...
    {'Algorithm','Function','Best','Worst','Mean','Median','Std','IQR','Seconds_per_run'}, rows);
% ---------------- Friedman + Holm ------------------------------------
Fr = friedman_test(Mmean);
[~, ord] = sort(Fr.avgRank);
rows = cell(k, 3);
for j = 1:k, a = ord(j); rows(j,:) = {j, names{a}, Fr.avgRank(a)}; end
write_csv(fullfile(root,'cec_friedman.csv'), {'Overall_rank','Algorithm','Average_rank'}, rows);
write_csv(fullfile(root,'cec_friedman_summary.csv'), {'N','k','chi2','df','p_chi2','F_ImanDavenport','p_FF','sum_of_ranks'}, ...
    {Fr.N, Fr.k, Fr.chi2, Fr.df, Fr.p_chi2, Fr.FF, Fr.p_FF, sum(Fr.avgRank)});
for ctl = {'best', 'HQBOM-I'}
    if strcmp(ctl{1}, 'best'), cidx = ord(1); tag = 'cec_holm.csv';
    else, cidx = find(strcmp(names, ctl{1})); tag = 'cec_holm_vs_HQBOM_I.csv'; end
    Ho = holm_posthoc(Fr.avgRank, nf, cidx);
    rows = cell(numel(Ho.others), 6);
    for j = 1:numel(Ho.others)
        rows(j,:) = {names{cidx}, names{Ho.others(j)}, Fr.avgRank(Ho.others(j)), Ho.z(j), Ho.p(j), Ho.pHolm(j)};
    end
    write_csv(fullfile(root, tag), {'Control','Algorithm','Average_rank','z','p_unadjusted','p_Holm'}, rows);
end
% ---------------- Wilcoxon rank-sum ----------------------------------
for ref = {'HQBOM-I', 'HQBOM-II'}
    ra = find(strcmp(names, ref{1}));
    rows = cell(nf, 1 + 2*(k-1)); hdr = {'Function'};
    W = zeros(k-1, 3); col = 1; others = setdiff(1:k, ra);
    P = zeros(nf, k-1); S = zeros(nf, k-1);
    for jj = 1:numel(others)
        b = others(jj);
        for i = 1:nf
            P(i,jj) = ranksum_test(E{i,ra}, E{i,b});
            S(i,jj) = sign(median(E{i,b}) - median(E{i,ra}));  % +: ref better
            if S(i,jj) == 0, S(i,jj) = sign(mean(E{i,b}) - mean(E{i,ra})); end
        end
    end
    PA = zeros(size(P));
    for jj = 1:numel(others), PA(:,jj) = holm_adjust(P(:,jj))'; end
    for i = 1:nf
        rows{i,1} = sprintf('F%d', fns(i));
        for jj = 1:numel(others)
            if PA(i,jj) < 0.05, mk = '+'; if S(i,jj) < 0, mk = '-'; end, else, mk = '='; end
            rows{i,2*jj} = PA(i,jj); rows{i,2*jj+1} = mk;
        end
    end
    for jj = 1:numel(others)
        hdr{end+1} = ['p_Holm_' names{others(jj)}]; hdr{end+1} = ['sign_' names{others(jj)}]; %#ok<AGROW>
        sg = rows(:, 2*jj+1);
        W(jj,:) = [sum(strcmp(sg,'+')), sum(strcmp(sg,'=')), sum(strcmp(sg,'-'))];
    end
    tagn = strrep(ref{1}, '-', '_');
    write_csv(fullfile(root, ['cec_ranksum_' tagn '.csv']), hdr, rows);
    rw = cell(numel(others), 4);
    for jj = 1:numel(others), rw(jj,:) = {names{others(jj)}, W(jj,1), W(jj,2), W(jj,3)}; end
    write_csv(fullfile(root, ['cec_wtl_' tagn '.csv']), {'Versus','Wins','Ties','Losses'}, rw);
end
% ---------------- convergence ----------------------------------------
ck = (1:100)/100 * 10000 * D;
rows = cell(nf*k*100, 4); c = 0;
for a = 1:k, for i = 1:nf
    m = mean(H{i,a}, 1);
    for j = 1:100, c = c + 1; rows(c,:) = {names{a}, sprintf('F%d',fns(i)), ck(j), m(j) - 100*fns(i)*0}; end
end, end
write_csv(fullfile(root,'cec_convergence.csv'), {'Algorithm','Function','FE','Mean_best_error'}, rows);
T.friedman = Fr; T.meanErr = Mmean; T.stdErr = Mstd; T.names = names;
save(fullfile(root, 'cec_summary.mat'), '-v7', 'T');
if exist('writetable', 'file') == 2 && ~exist('OCTAVE_VERSION', 'builtin')
    export_csv_folder_to_excel(root, fullfile(root, 'HQBOM_CEC2017_results.xlsx'));
end
end
