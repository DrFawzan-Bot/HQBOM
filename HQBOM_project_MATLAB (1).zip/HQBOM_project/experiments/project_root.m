function r = project_root()
%PROJECT_ROOT  Absolute path of the project folder.
r = fileparts(fileparts(mfilename('fullpath')));
end
