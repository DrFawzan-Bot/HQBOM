function C = tuning_configs()
%TUNING_CONFIGS  Candidate settings examined in the tuning study.
C = struct('name', {}, 'fun', {});
for rho = [0.05 0.1 0.2 0.3 0.5]
    C(end+1) = struct('name', sprintf('HQBOM-I rho=%.2f', rho), ...
        'fun', @(p, fe) hqbom1(p, fe, struct(), struct(), struct('rho', rho))); %#ok<AGROW>
end
C(end+1) = struct('name', 'HQBOM-II fail g=2 best', 'fun', @(p, fe) hqbom2(p, fe, struct(), struct(), ...
    struct('trigger', 'fail', 'gInj', 2, 'restart', 'best')));
C(end+1) = struct('name', 'HQBOM-II fail g=2 qbom', 'fun', @(p, fe) hqbom2(p, fe, struct(), struct(), ...
    struct('trigger', 'fail', 'gInj', 2, 'restart', 'qbom')));
for g = [5 25]
    for rs = {'best', 'qbom'}
        C(end+1) = struct('name', sprintf('HQBOM-II stall g=%d %s', g, rs{1}), ...
            'fun', @(p, fe) hqbom2(p, fe, struct(), struct(), ...
            struct('trigger', 'stall', 'gInj', g, 'restart', rs{1}))); %#ok<AGROW>
    end
end
end
