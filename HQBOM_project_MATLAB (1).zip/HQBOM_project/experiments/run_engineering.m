function run_engineering(algIdx, probIdx, nRuns)
%RUN_ENGINEERING  Controlled engineering-design experiment (Section 6.2).
%   Every algorithm is run NRUNS times (default 30) on every problem with
%   the same FE budget, the same constraint handling (Deb's rules through
%   FE_EVAL), the same discrete-variable repair and the same seeds
%   rng(seed_base('eng') + 5000*problem + run). Results: results/engineering/raw/*.mat
A = algorithm_registry(); P = engineering_registry();
if nargin < 1 || isempty(algIdx),  algIdx = 1:numel(A); end
if nargin < 2 || isempty(probIdx), probIdx = 1:numel(P); end
if nargin < 3 || isempty(nRuns),   nRuns = 30; end
out = fullfile(project_root(), 'results', 'engineering', 'raw');
if ~exist(out, 'dir'), [~, ~] = mkdir(out); end   % tolerant to parallel workers
for q = probIdx
    p = P(q).make();
    for a = algIdx
        fn = fullfile(out, sprintf('%s_%s.mat', strrep(A(a).name,'-','_'), P(q).tag));
        if exist(fn, 'file'), continue; end
        f = zeros(nRuns,1); v = f; feBest = f; X = zeros(nRuns, p.D); hist = zeros(nRuns,100);
        for r = 1:nRuns
            rng(seed_base('eng') + 5000*q + r);
            Rr = A(a).fun(p, P(q).maxFE);
            f(r) = Rr.bestF; v(r) = Rr.bestV; feBest(r) = Rr.feAtBest;
            X(r,:) = Rr.bestX; hist(r,:) = Rr.histF;
        end
        alg = A(a).name; prob = P(q).tag; maxFE = P(q).maxFE; sense = P(q).sense; %#ok<NASGU>
        save(fn, '-v7', 'alg', 'prob', 'maxFE', 'sense', 'f', 'v', 'feBest', 'X', 'hist');
        fprintf('%-6s %-9s best=%.6f mean=%.6f feasible=%d/%d\n', P(q).tag, A(a).name, ...
                min(f(v<=0)), mean(f(v<=0)), nnz(v<=0), nRuns);
    end
end
end
