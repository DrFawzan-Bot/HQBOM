function analyze_engineering()
%ANALYZE_ENGINEERING  Statistics for the controlled engineering study.
%   Reads results/engineering/raw/*.mat and writes to results/engineering:
%     eng_runs.csv         run-level objective, violation, FE-at-best, x
%     eng_descriptive.csv  Best/Worst/Mean/Median/Std/IQR over FEASIBLE
%                          runs, feasibility rate, mean FE to best
%     eng_best_solutions.csv  best feasible design of every algorithm
%     eng_friedman.csv     average ranks over the problems (rank key:
%                          feasibility rate, then mean feasible objective)
%     eng_holm.csv         Holm post-hoc vs the best-ranked algorithm
%     eng_ranksum_HQBOM_I.csv  rank-sum tests (Deb key) HQBOM-I vs others
%   For the IC-engine problem the stored objective is -power; reported
%   statistics are converted back to power (kW/L, larger is better).
A = algorithm_registry(); P = engineering_registry(); k = numel(A); np = numel(P);
root = fullfile(project_root(), 'results', 'engineering'); raw = fullfile(root, 'raw');
names = {A.name};
runs = {}; desc = {}; bestsol = {}; RK = zeros(np, k);
KEY = cell(np, k);
for q = 1:np
    prob = P(q).make(); sg = P(q).sense;
    meanF = inf(1,k); rate = zeros(1,k);
    for a = 1:k
        L = load(fullfile(raw, sprintf('%s_%s.mat', strrep(names{a},'-','_'), P(q).tag)));
        n = numel(L.f); fe = L.v <= 0;
        KEY{q,a} = deb_key(L.f, L.v);
        for r = 1:n
            runs(end+1,:) = {P(q).tag, names{a}, r, sg*L.f(r), L.v(r), L.feBest(r), mat2str(L.X(r,:), 10)}; %#ok<AGROW>
        end
        rate(a) = mean(fe);
        if any(fe)
            s = desc_stats(sg*L.f(fe));
            if sg < 0, tmp = s.best; s.best = s.worst; s.worst = tmp; end   % larger = better
            meanF(a) = mean(L.f(fe));
            [~, ib] = min(L.f + 1e300*(~fe));
            xb = L.X(ib,:);
            if isfield(prob, 'decode'), xb = prob.decode(xb); end
            bestsol(end+1,:) = {P(q).tag, names{a}, sg*L.f(ib), mat2str(xb, 10)}; %#ok<AGROW>
            desc(end+1,:) = {P(q).tag, names{a}, s.best, s.worst, s.mean, s.median, s.std, s.iqr, 100*rate(a), mean(L.feBest(fe))}; %#ok<AGROW>
        else
            desc(end+1,:) = {P(q).tag, names{a}, NaN, NaN, NaN, NaN, NaN, NaN, 0, NaN}; %#ok<AGROW>
        end
    end
    % rank: higher feasibility first, then lower mean objective (ties averaged)
    score = (1 - rate) * 1e12 + meanF;  score(~isfinite(meanF)) = 1e13;
    % objective values are rounded to 1e-6 relative so numerically equal
    % results share a rank
    sc = round(score * 1e6) / 1e6;
    RK(q,:) = tied_rank(sc)';
end
write_csv(fullfile(root,'eng_runs.csv'), {'Problem','Algorithm','Run','Objective','Violation','FE_at_best','x'}, runs);
write_csv(fullfile(root,'eng_descriptive.csv'), {'Problem','Algorithm','Best','Worst','Mean','Median','Std','IQR','Feasible_pct','Mean_FE_to_best'}, desc);
write_csv(fullfile(root,'eng_best_solutions.csv'), {'Problem','Algorithm','Best_objective','Design_vector'}, bestsol);
avg = mean(RK, 1);
N = np; chi2 = 12*N/(k*(k+1))*(sum(avg.^2) - k*(k+1)^2/4);
pchi = 1 - gammainc(chi2/2, (k-1)/2);
[~, ord] = sort(avg);
rows = cell(k,3); for j = 1:k, rows(j,:) = {j, names{ord(j)}, avg(ord(j))}; end
write_csv(fullfile(root,'eng_friedman.csv'), {'Overall_rank','Algorithm','Average_rank'}, rows);
write_csv(fullfile(root,'eng_friedman_summary.csv'), {'N','k','chi2','p_chi2','sum_of_ranks'}, {N, k, chi2, pchi, sum(avg)});
Ho = holm_posthoc(avg, N, ord(1));
rows = cell(numel(Ho.others), 6);
for j = 1:numel(Ho.others)
    rows(j,:) = {names{ord(1)}, names{Ho.others(j)}, avg(Ho.others(j)), Ho.z(j), Ho.p(j), Ho.pHolm(j)};
end
write_csv(fullfile(root,'eng_holm.csv'), {'Control','Algorithm','Average_rank','z','p_unadjusted','p_Holm'}, rows);
rows = cell(np*(k-1), 5); c = 0; ra = find(strcmp(names,'HQBOM-I'));
for q = 1:np
    others = setdiff(1:k, ra); pv = zeros(1, k-1); sgn = pv;
    for jj = 1:numel(others)
        b = others(jj);
        pv(jj) = ranksum_test(KEY{q,ra}, KEY{q,b});
        sgn(jj) = sign(median(KEY{q,b}) - median(KEY{q,ra}));
        if sgn(jj) == 0, sgn(jj) = sign(mean(KEY{q,b}) - mean(KEY{q,ra})); end
    end
    pa = holm_adjust(pv);
    for jj = 1:numel(others)
        mk = '='; if pa(jj) < 0.05, if sgn(jj) > 0, mk = '+'; else, mk = '-'; end, end
        c = c + 1; rows(c,:) = {P(q).tag, names{others(jj)}, pv(jj), pa(jj), mk};
    end
end
write_csv(fullfile(root,'eng_ranksum_HQBOM_I.csv'), {'Problem','Versus','p','p_Holm','sign'}, rows);
if exist('writetable', 'file') == 2 && ~exist('OCTAVE_VERSION', 'builtin')
    export_csv_folder_to_excel(root, fullfile(root, 'HQBOM_engineering_results.xlsx'));
end
end
