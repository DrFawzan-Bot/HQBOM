function out = friedman_test(M)
%FRIEDMAN_TEST  Friedman test for N problems (rows) x k algorithms (cols).
%   M holds the performance measure (lower is better, e.g. mean error).
%   Ranks are assigned within each row (ties -> average rank), so the
%   average ranks always sum to k(k+1)/2. Returns average ranks, the
%   Friedman chi-square (k-1 d.o.f.) and the Iman-Davenport F statistic
%   ((k-1), (k-1)(N-1) d.o.f.) with their p-values.
[N, k] = size(M);
Rk = zeros(N, k);
for i = 1:N, Rk(i,:) = tied_rank(M(i,:))'; end
out.ranks   = Rk;
out.avgRank = mean(Rk, 1);
out.chi2    = 12*N/(k*(k+1)) * (sum(out.avgRank.^2) - k*(k+1)^2/4);
out.df      = k - 1;
out.p_chi2  = 1 - gammainc(out.chi2/2, (k-1)/2);
out.FF      = (N-1)*out.chi2 / (N*(k-1) - out.chi2);
d1 = k-1; d2 = (k-1)*(N-1);
out.p_FF    = betainc(d2/(d2 + d1*out.FF), d2/2, d1/2);
out.N = N; out.k = k;
end
