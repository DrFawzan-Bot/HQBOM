function out = holm_posthoc(avgRank, N, control)
%HOLM_POSTHOC  Post-hoc comparison of all algorithms with a control
%   algorithm after a significant Friedman test (Demsar 2006; Garcia &
%   Herrera 2008): z_i = (R_i - R_c) / sqrt(k(k+1)/(6N)), two-sided
%   unadjusted p_i, and Holm's step-down adjusted p-values.
k = numel(avgRank);
if nargin < 3, [~, control] = min(avgRank); end
se = sqrt(k*(k+1)/(6*N));
others = setdiff(1:k, control);
z = (avgRank(others) - avgRank(control)) / se;
p = erfc(abs(z)/sqrt(2));
[ps, ord] = sort(p);
m = numel(ps); adj = zeros(1, m);
run = 0;
for i = 1:m
    run = max(run, min(1, (m - i + 1) * ps(i)));
    adj(i) = run;
end
pa = zeros(1, m); pa(ord) = adj;
out.control = control; out.others = others;
out.z = z; out.p = p; out.pHolm = pa;
end
