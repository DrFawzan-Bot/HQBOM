function pa = holm_adjust(p)
%HOLM_ADJUST  Holm step-down adjusted p-values for a family of tests.
p = p(:)'; m = numel(p);
[ps, ord] = sort(p); adj = zeros(1,m); run = 0;
for i = 1:m
    run = max(run, min(1, (m - i + 1)*ps(i)));
    adj(i) = run;
end
pa = zeros(1,m); pa(ord) = adj;
end
