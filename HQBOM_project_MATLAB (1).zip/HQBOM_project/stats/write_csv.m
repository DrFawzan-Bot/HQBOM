function write_csv(fname, header, rows)
%WRITE_CSV  Write a cell array ROWS (n-by-m; numbers or text) with HEADER
%   (1-by-m cell) to a comma-separated file (MATLAB and Octave).
fid = fopen(fname, 'w');
fprintf(fid, '%s\n', strjoin(header, ','));
for i = 1:size(rows,1)
    c = cell(1, size(rows,2));
    for j = 1:size(rows,2)
        x = rows{i,j};
        if ischar(x), c{j} = x;
        elseif isempty(x) || (isnumeric(x) && isnan(x)), c{j} = '';
        elseif isnumeric(x) && x == round(x) && abs(x) < 1e15, c{j} = sprintf('%d', x);
        else, c{j} = sprintf('%.10g', x);
        end
    end
    fprintf(fid, '%s\n', strjoin(c, ','));
end
fclose(fid);
end
