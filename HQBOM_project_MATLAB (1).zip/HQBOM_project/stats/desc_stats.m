function s = desc_stats(x)
%DESC_STATS  Best, worst, mean, median, standard deviation and IQR of x.
%   Quartiles use linear interpolation between order statistics
%   (Hyndman & Fan type 7, the default of R and NumPy).
x = sort(x(:)); n = numel(x);
q = @(pp) interp1(1:n, x, 1 + (n-1)*pp);
if n == 1, q = @(pp) x; end
s.best = x(1); s.worst = x(end); s.mean = mean(x); s.median = q(0.5);
s.std = std(x); s.iqr = q(0.75) - q(0.25);
end
