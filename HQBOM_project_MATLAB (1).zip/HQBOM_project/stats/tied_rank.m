function r = tied_rank(x)
%TIED_RANK  Ranks of the vector x (1 = smallest), ties get average ranks.
x = x(:); n = numel(x);
[xs, i] = sort(x);
r = zeros(n,1); k = 1;
while k <= n
    j = k;
    while j < n && xs(j+1) == xs(k), j = j + 1; end
    r(i(k:j)) = (k + j) / 2;
    k = j + 1;
end
end
