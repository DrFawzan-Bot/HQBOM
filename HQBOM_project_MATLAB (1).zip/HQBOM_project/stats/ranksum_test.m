function [p, z] = ranksum_test(x, y)
%RANKSUM_TEST  Two-sided Wilcoxon rank-sum (Mann-Whitney U) test for two
%   INDEPENDENT samples, normal approximation with tie correction and
%   continuity correction. Runs of two stochastic algorithms are not
%   paired, hence the unpaired test is used.
x = x(:); y = y(:); nx = numel(x); ny = numel(y); n = nx + ny;
r = tied_rank([x; y]);
W = sum(r(1:nx));
mu = nx*(n+1)/2;
[~, ~, g] = unique([x; y]); t = accumarray(g, 1);
sig2 = nx*ny/12 * ((n+1) - sum(t.^3 - t)/(n*(n-1)));
if sig2 <= 0, p = 1; z = 0; return; end
d = W - mu;
z = (d - 0.5*sign(d)) / sqrt(sig2);
p = erfc(abs(z)/sqrt(2));
end
