/* MEX gateway for the official CEC2017 bound-constrained benchmark
   (P. N. Suganthan et al.).  Usage:  f = cec17_func(X, func_num)
   X : D-by-N matrix (each column is one candidate), D in {10,30,50,100}
   f : 1-by-N vector of objective values (F_i(x); F_i* = 100*i)
   The folder input_data must reside next to this file.               */
#include "mex.h"
#include <string.h>
double *OShift=NULL,*M=NULL,*y=NULL,*z=NULL,*x_bound=NULL;
int ini_flag=0,n_flag,func_flag,*SS=NULL;
char cec17_dir[1024]="";
#include "cec17_test_func.cpp"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    if (nrhs < 2) mexErrMsgTxt("Usage: f = cec17_func(X, func_num)");
    if (cec17_dir[0] == '\0') {               /* locate input_data once */
        mxArray *out[1], *in[1];
        in[0] = mxCreateString("cec17_func");
        mexCallMATLAB(1, out, 1, in, "which");
        char *p = mxArrayToString(out[0]);
        char *s = strrchr(p, '/'); if (!s) s = strrchr(p, '\\');
        if (s) { s[1] = '\0'; strncpy(cec17_dir, p, 1023); }
        mxFree(p); mxDestroyArray(out[0]); mxDestroyArray(in[0]);
    }
    int m = (int)mxGetM(prhs[0]);
    int n = (int)mxGetN(prhs[0]);
    int func_num = (int)mxGetScalar(prhs[1]);
    double *x = mxGetPr(prhs[0]);
    plhs[0] = mxCreateDoubleMatrix(1, n, mxREAL);
    double *f = mxGetPr(plhs[0]);
    cec17_test_func(x, f, m, n, func_num);
}
