function p = chped_5unit()
%CHPED_5UNIT  Combined heat and power economic dispatch, 5-unit system
%   (Vasebi et al. 2007): unit 1 power-only, units 2-4 cogeneration
%   (non-convex feasible operating regions, FOR), unit 5 heat-only.
%   P_D = 300 MW, H_D = 150 MWth. Equalities are enforced exactly by
%   eliminating P1 = 300 - (P2+P3+P4) and H5 = 150 - (H2+H3+H4); their
%   limits become constraints. Decision x = [P2 H2 P3 H3 P4 H4].
%   Violation of a FOR = Euclidean distance (MW) from (P,H) to the region.
p.name  = 'CHPED (5 units)';
p.D     = 6;
p.lb    = [40 0  10 0  35 0];
p.ub    = [125.8 135.6 60 55 105 45];
p.dstep = zeros(1, 6);
p.fobj  = @obj;
p.decode = @(x) [300 - x(:,1) - x(:,3) - x(:,5), x, 150 - x(:,2) - x(:,4) - x(:,6)];
p.vars  = {'P1','P2','H2','P3','H3','P4','H4','H5'};
end
function [f, v] = obj(X)
P2 = X(:,1); H2 = X(:,2); P3 = X(:,3); H3 = X(:,4); P4 = X(:,5); H4 = X(:,6);
P1 = 300 - P2 - P3 - P4;
H5 = 150 - H2 - H3 - H4;
c1 = 254.8863 + 7.6997*P1 + 0.00172*P1.^2 + 0.000115*P1.^3;
c2 = 1250 + 36*P2   + 0.0435*P2.^2 + 0.6*H2   + 0.027*H2.^2 + 0.011*P2.*H2;
c3 = 2650 + 34.5*P3 + 0.1035*P3.^2 + 2.203*H3 + 0.025*H3.^2 + 0.051*P3.*H3;
c4 = 1565 + 20*P4   + 0.072*P4.^2  + 2.3*H4   + 0.02*H4.^2  + 0.04*P4.*H4;
c5 = 950  + 2.0109*H5 + 0.038*H5.^2;
f = c1 + c2 + c3 + c4 + c5;
% Feasible operating regions, vertices given as (P, H)
R2 = [44 0; 44 15.9; 40 75; 110.2 135.6; 125.8 32.4; 125.8 0];
R3 = [20 0; 10 40; 45 55; 60 0];
R4 = [35 0; 35 20; 90 45; 90 25; 105 0];
v = max(35 - P1, 0) + max(P1 - 135, 0) + max(-H5, 0) + max(H5 - 60, 0) ...
    + for_violation(P2, H2, R2) + for_violation(P3, H3, R3) ...
    + for_violation(P4, H4, R4);
end
function d = for_violation(P, H, Rv)
in = inpolygon(P, H, Rv(:,1), Rv(:,2));
d = zeros(size(P));
out = find(~in);
if isempty(out), return; end
A = Rv; B = Rv([2:end 1], :);
dm = inf(numel(out), 1);
for e = 1:size(A,1)
    ab = B(e,:) - A(e,:);
    t = ((P(out) - A(e,1))*ab(1) + (H(out) - A(e,2))*ab(2)) / (ab*ab');
    t = min(max(t, 0), 1);
    dx = A(e,1) + t*ab(1) - P(out);
    dy = A(e,2) + t*ab(2) - H(out);
    dm = min(dm, sqrt(dx.^2 + dy.^2));
end
d(out) = dm;
end
