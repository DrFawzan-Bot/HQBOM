function p = sced_2gen()
%SCED_2GEN  Security-constrained economic dispatch, 2-machine 5-bus system
%   (Youssef & El-Naggar 2000). Powers in p.u. (base 100 MW); fuel costs
%   in $/h evaluated with P in MW. The power-balance equality
%   Pg1 + Pg2 = 7 is satisfied exactly by eliminating Pg2 = 7 - Pg1 (slack
%   generator); its limits become a constraint. Decision: x = Pg1.
p.name  = 'SCED (2 generators)';
p.D     = 1;
p.lb    = 3; p.ub = 7;
p.dstep = 0;
p.fobj  = @obj;
p.decode = @(x) [x(:,1), 7 - x(:,1)];
p.vars  = {'Pg1','Pg2'};
end
function [f, v] = obj(X)
P1 = X(:,1); P2 = 7 - P1;
f = 155.5 + 0.489*(100*P1) + 0.00393*(100*P1).^2 + ...
    59.4  + 0.703*(100*P2) + 0.00745*(100*P2).^2;
g = [ 1 - P2, P2 - 4, ...
      4*P1 - 19*P2 - 1, ...
      9.625*P1 - 38.125*P2 + 2, ...
      68.875*P1 - 111.875*P2 - 209, ...
      87.812*P1 - 115.371*P2 - 325, ...
      112.687*P1 - 141.125*P2 - 320 ];
v = sum(max(g, 0), 2);
end
