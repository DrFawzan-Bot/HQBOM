function p = spring_design()
%SPRING_DESIGN  Tension/compression spring (Arora 1989). x = [d D N].
p.name  = 'Tension/compression spring';
p.D     = 3;
p.lb    = [0.05 0.25 2];
p.ub    = [2.00 1.30 15];
p.dstep = [0 0 0];
p.fobj  = @obj;
p.vars  = {'d','D','N'};
end
function [f, v] = obj(X)
d = X(:,1); D = X(:,2); N = X(:,3);
f = (N + 2) .* D .* d.^2;
g = [ 1 - D.^3.*N ./ (71785*d.^4), ...
      (4*D.^2 - d.*D) ./ (12566*(D.*d.^3 - d.^4)) + 1 ./ (5108*d.^2) - 1, ...
      1 - 140.45*d ./ (D.^2.*N), ...
      (D + d)/1.5 - 1 ];
v = sum(max(g, 0), 2);
end
