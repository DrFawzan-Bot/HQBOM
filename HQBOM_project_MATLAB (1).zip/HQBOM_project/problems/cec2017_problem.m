function p = cec2017_problem(fn, D)
%CEC2017_PROBLEM  CEC2017 bound-constrained function F_fn in dimension D.
%   Uses the official C code of Suganthan et al. through the MEX gateway
%   cec17_func (folder cec2017). The returned objective is the ERROR
%   f(x) - F_fn*, with F_fn* = 100*fn, on the box [-100, 100]^D.
%   F2 is excluded from the study (unstable in the official code and
%   removed by the organisers), so fn must be 1 or 3..30.
p.name  = sprintf('CEC2017-F%d', fn);
p.D     = D;
p.lb    = -100 * ones(1, D);
p.ub    =  100 * ones(1, D);
p.dstep = zeros(1, D);
p.fobj  = @(X) cec_obj(X, fn);
end
function [f, v] = cec_obj(X, fn)
f = cec17_func(X', fn)' - 100 * fn;
v = zeros(size(f));
end
