function p = ic_engine()
%IC_ENGINE  Flat-head combustion-chamber design of a 1.86 L four-cylinder
%   engine (Papalambros & Wilde; McAllister & Simpson 2003).
%   x = [b dI dE cr w]: bore (mm), intake / exhaust valve diameters (mm),
%   compression ratio, speed at peak power w (1000 rpm).
%   The objective returned is f = K0*(FMEP - (rho*Q/Af)*eta_t*eta_v)*w,
%   i.e. MINUS the brake power per litre (kW/L); maximising power is
%   minimising f. Constraints g1..g9 are written in normalised form.
p.name  = 'IC engine';
p.D     = 5;
p.lb    = [70 25 25  6  5];
p.ub    = [90 50 50 12 12];
p.dstep = zeros(1, 5);
p.fobj  = @obj;
p.vars  = {'b','dI','dE','cr','w'};
end
function [f, v] = obj(X)
b = X(:,1); dI = X(:,2); dE = X(:,3); cr = X(:,4); w = X(:,5);
Nc = 4; V = 1.859e6; Q = 43958; Af = 14.6; Cs = 0.44; rho = 1.225;
K0 = 1/120; K1 = 1.2; K2 = 2; K3 = 0.82; K4 = 0.83; K5 = 0.89; K6 = 0.6;
K7 = 6.5; K8 = 230.5; L1 = 400; L2 = 200;
etatad = 0.8595 * (1 - cr.^(-0.33));
Sv  = 0.83 * ((8 + 4*cr) + 1.5*(cr - 1).*(pi*Nc/V).*b.^3) ./ ((2 + cr).*b);
etat = etatad - Sv .* sqrt(1.5 ./ w);
etavb = 0.637 + 0.13*w - 0.014*w.^2 + 0.00066*w.^3;
hi = w >= 5.25;
etavb(hi) = 1.067 - 0.038*exp(w(hi) - 5.25);
mach = 9.428e-5 * (4*V/(pi*Nc*Cs)) * (w ./ dI.^2);
etav = etavb .* (1 + 5.96e-3*w.^2) ./ (1 + mach.^2);
Vp   = (8*V/(pi*Nc)) * w .* b.^(-2);
FMEP = 4.826*(cr - 9.2) + (7.97 + 0.253*Vp + 9.7e-6*Vp.^2);
f = K0 * (FMEP - (rho*Q/Af) * etat .* etav) .* w;
etatw = etatad - Sv;
g = [ K1*Nc*b/L1 - 1, ...
      sqrt(4*K2*V/(pi*Nc*L2)) ./ b - 1, ...
      (dI + dE) ./ (K3*b) - 1, ...
      K4*dI ./ dE - 1, ...
      dE ./ (K5*dI) - 1, ...
      9.428e-5*(4*V/(pi*Nc))*(w ./ dI.^2) / (K6*Cs) - 1, ...
      (cr + 0.045*b)/13.2 - 1, ...
      w/K7 - 1, ...
      1 - K8*Q*etatw/3.6e6 ];
v = sum(max(g, 0), 2);
end
