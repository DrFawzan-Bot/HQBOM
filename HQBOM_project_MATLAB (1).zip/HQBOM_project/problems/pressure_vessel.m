function p = pressure_vessel()
%PRESSURE_VESSEL  Mixed-discrete pressure-vessel design (Sandgren 1990;
%   Kannan & Kramer 1994). x = [Ts Th R L]; Ts, Th are integer multiples
%   of 0.0625 in. Variant used here: 4 constraints, L <= 240 in.
p.name  = 'Pressure vessel';
p.D     = 4;
p.lb    = [0.0625 0.0625 10 10];
p.ub    = [1.25   1.25   200 240];
p.dstep = [0.0625 0.0625 0 0];
p.fobj  = @obj;
p.vars  = {'Ts','Th','R','L'};
end
function [f, v] = obj(X)
Ts = X(:,1); Th = X(:,2); R = X(:,3); L = X(:,4);
f = 0.6224*Ts.*R.*L + 1.7781*Th.*R.^2 + 3.1661*Ts.^2.*L + 19.84*Ts.^2.*R;
g = [ -Ts + 0.0193*R, ...
      -Th + 0.00954*R, ...
      (-pi*R.^2.*L - (4/3)*pi*R.^3) / 1296000 + 1, ...
      L/240 - 1 ];
v = sum(max(g, 0), 2);
end
