function p = sced_7gen()
%SCED_7GEN  Economic dispatch, 7-machine 10-bus test (generator data of
%   Youssef & El-Naggar 2000 as listed in the paper). Powers in p.u. (base
%   100 MW), costs with P in MW. Power balance sum(Pg) = 11.5 p.u. is
%   enforced by eliminating Pg7 (slack); its limits become constraints.
%   Decision: x = [Pg1 .. Pg6].
p.name  = 'SCED (7 generators)';
p.D     = 6;
p.lb    = [1 1.5 1 2 0.75 0.75];
p.ub    = [3 4   3 6 2.5  2.5];
p.dstep = zeros(1, 6);
p.fobj  = @obj;
p.decode = @(x) [x, 11.5 - sum(x, 2)];
p.vars  = {'Pg1','Pg2','Pg3','Pg4','Pg5','Pg6','Pg7'};
end
function [f, v] = obj(X)
P = 100 * [X, 11.5 - sum(X, 2)];
a = [155.5 310 155.5 561 255 155.5 77.3];
b = [0.489 0.75 0.489 0.75 0.84 0.489 0.546];
c = [0.00393 0.00745 0.00393 0.00745 0.005 0.005 0.00773];
f = sum(a + b.*P + c.*P.^2, 2);
P7 = P(:,7) / 100;
v = max(0.5 - P7, 0) + max(P7 - 1, 0);
end
