function X = repair_point(X, p)
%REPAIR_POINT  Project candidates onto the box and the discrete grid.
%   Continuous variables are clipped to [lb, ub]. A variable with
%   p.dstep(j) > 0 is rounded to the nearest admissible value
%   lb(j) + k*dstep(j) and then clipped (e.g. integer variables use
%   dstep = 1, plate thicknesses use dstep = 0.0625 in).
X = min(max(X, p.lb), p.ub);
if isfield(p, 'dstep') && any(p.dstep > 0)
    j = find(p.dstep > 0);
    for k = j
        X(:,k) = p.lb(k) + round((X(:,k) - p.lb(k)) / p.dstep(k)) * p.dstep(k);
    end
    X = min(max(X, p.lb), p.ub);
end
end
