function R = hqbom1(prob, maxFE, oq, op, oh)
%HQBOM1  HQBOM-I: global QBOM followed by local Pattern Search.
%   Cycle c = 1, 2, ...:
%     (a) QBOM phase: QBOM (Algorithm 1) is run on a freshly initialised
%         population (for c > 1 the best solution so far is inserted as
%         one vector) for B_c = floor(rho * FE_rem) evaluations, where
%         FE_rem is the budget remaining at the start of the cycle.
%     (b) PS phase: GPS (ps_poll) starts from x_best with mesh = mesh0 and
%         polls until mesh < meshTol or the budget is spent.
%   If budget remains after (b), a new cycle starts. FE_QBOM + FE_PS <= FEmax
%   is guaranteed by FE_EVAL. rho: see HQBOM_DEFAULTS.
if nargin < 3, oq = struct(); end
if nargin < 4, op = struct(); end
if nargin < 5, oh = struct(); end
if isnumeric(oh), oh = struct('rho', oh); end
oh = hqbom_defaults(oh); rho = oh.rho;
op = ps_defaults(op);
S = fe_init(prob, maxFE);
cycle = 0;
while S.fe < S.maxFE
    cycle = cycle + 1;
    feRem = S.maxFE - S.fe;
    BQ = max(floor(rho * feRem), 1);
    stopQ = S.fe + BQ;
    % ----- (a) QBOM global phase -------------------------------------
    seed = [];
    if cycle > 1, seed = S.bestX; end
    oq1 = qbom_defaults(oq);
    [stq, S] = qbom_init(S, oq, seed, max(1, floor(BQ / (2*oq1.n))));
    while S.fe < stopQ && S.fe < S.maxFE
        [stq, S] = qbom_step(stq, S, 1);
    end
    if S.fe >= S.maxFE, break; end
    % ----- (b) PS local phase from x_best ----------------------------
    st = ps_init(S.bestX, S.bestF, S.bestV, op);
    while S.fe < S.maxFE && st.mesh >= op.meshTol
        [st, S] = ps_poll(st, S);
    end
end
R = run_result(S);
R.cycles = cycle;
end
