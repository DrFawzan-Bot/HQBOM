function o = qbom_defaults(o)
%QBOM_DEFAULTS  Control parameters of QBOM (Table 2 of the paper).
%   Port of the authors' reference code QBOM1.m (see
%   original_QBOM1_reference.m.txt) to the budget-safe framework.
%   n         population size                                   80
%   gate      quantum gate used by Renew Qubits                 2
%             1 rotation, 2 Hadamard, 3 CNOT, 4 QNOT, 5 Z gate,
%             6 anti-symmetric C gate
%   ls        local search around x_best                        1
%             0 none, 1 uniform sampling in the reduced box
%             x_best +/- w*(ub-lb), 2/3/4 relative-distance jump
%             (max / min / mean of (x_best - x_best_old)./x_best_old)
%   w         half-width of the reduced box of local search 1   0.15
%   Rmode     'scalar': ONE water level r ~ U(0,1) shared by all bits,
%             exactly as R = rand*ones(n,D) in QBOM1.m (default);
%             'matrix': independent r_ij ~ U(0,1)
%   lsClip    'symmetric' (default): [x_best -/+ w(ub-lb)] clipped to
%             [lb, ub] on both sides - the evidently intended behaviour of
%             QBOM1.m; 'original': reproduces QBOM1.m literally - the line
%             "if newUB(j) > LB(j), newUB(j) = UB(j)" always sets the upper
%             limit to ub, giving the one-sided box [x_best - w(ub-lb), ub]
if nargin < 1, o = struct(); end
d = struct('n', 80, 'gate', 2, 'ls', 1, 'w', 0.15, 'Rmode', 'scalar', ...
           'lsClip', 'symmetric');
fn = fieldnames(d);
for k = 1:numel(fn)
    if ~isfield(o, fn{k}), o.(fn{k}) = d.(fn{k}); end
end
end
