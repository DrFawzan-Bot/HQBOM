function oh = hqbom_defaults(oh)
%HQBOM_DEFAULTS  Control parameters of the hybrids (Table 2 of the paper).
%   Values were selected on the CEC2017 suite in dimension D = 10
%   (experiments/tune_hqbom.m), which is disjoint from the D = 30 test
%   set and from the engineering problems.
%   rho      HQBOM-I: QBOM share of the remaining budget in every cycle
%   trigger  HQBOM-II: 'fail'  - inject QBOM after every unsuccessful poll
%                      'stall' - inject QBOM only when PS has converged
%                                (mesh < meshTol)
%   gInj     HQBOM-II: QBOM generations per injection (2n FEs each)
%   restart  HQBOM-II: after an injection that does not improve x_best,
%            PS restarts from 'best' (x_best, mesh0) or from 'qbom' (the
%            best vector of the current QBOM population, mesh0)
if nargin < 1, oh = struct(); end
d = struct('rho', 0.5, 'trigger', 'fail', 'gInj', 2, 'restart', 'qbom');
fn = fieldnames(d);
for k = 1:numel(fn)
    if ~isfield(oh, fn{k}), oh.(fn{k}) = d.(fn{k}); end
end
end
