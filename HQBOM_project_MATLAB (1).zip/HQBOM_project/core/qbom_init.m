function [st, S] = qbom_init(S, o, seedX, maxIter)
%QBOM_INIT  Initialisation phase of QBOM (Algorithm 1, lines 1-5).
%   alpha_ij = 1/sqrt(2) for every qubit; the auxiliary amplitude used by
%   the QNOT, Z and C gates is Beta0 = sqrt(1 - |alpha|) (as in QBOM1.m);
%   the water level(s) R are drawn once (see qbom_defaults, Rmode); the n
%   vectors are sampled uniformly in [lb, ub] and evaluated.
%   SEEDX (optional, k-by-D) replaces the first k vectors (hybrids).
%   MAXITER is the planned number of generations; it only scales the
%   angle increment of the rotation gate (per = t/MaxIter).
o = qbom_defaults(o);
p = S.prob; n = o.n; m = p.D;
if nargin < 4 || isempty(maxIter), maxIter = max(1, floor((S.maxFE - S.fe - n) / (2*n))); end
st.o = o;
st.A = ones(n, m) / sqrt(2);
st.Beta0 = sqrt(1 - abs(st.A));
X = p.lb + rand(n, m) .* (p.ub - p.lb);
if strcmp(o.Rmode, 'scalar'), st.R = rand * ones(n, m); else, st.R = rand(n, m); end
if nargin > 2 && ~isempty(seedX)
    k = min(size(seedX,1), n); X(1:k,:) = seedX(1:k,:);
end
[f, v, X, S, K] = fe_eval(S, X);
st.X = X; st.F = f; st.V = v; st.K = K; st.n = size(X,1);
st.xbestOld = S.bestX;
st.maxIter = maxIter; st.per = 1 / maxIter; st.gen = 0;
end
