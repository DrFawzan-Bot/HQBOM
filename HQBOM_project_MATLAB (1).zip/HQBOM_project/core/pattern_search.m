function R = pattern_search(prob, maxFE, o)
%PATTERN_SEARCH  Stand-alone multi-start Pattern Search (GPS, 2N basis, complete poll).
%   The search starts from a uniformly random point; whenever the mesh
%   falls below meshTol it is restarted from a new uniformly random point
%   (the best solution found so far is retained), until MAXFE is used.
if nargin < 3, o = struct(); end
o = ps_defaults(o);
S = fe_init(prob, maxFE);
while S.fe < S.maxFE
    x0 = prob.lb + rand(1, prob.D) .* (prob.ub - prob.lb);
    [f0, v0, x0, S] = fe_eval(S, x0);
    if isempty(f0), break; end
    st = ps_init(x0, f0, v0, o);
    while S.fe < S.maxFE && st.mesh >= o.meshTol
        [st, S] = ps_poll(st, S);
    end
end
R = run_result(S);
end
