function st = ps_init(x, f, v, o)
%PS_INIT  Initialise a GPS pattern-search state at incumbent x.
o = ps_defaults(o);
st.o = o; st.x = x; st.f = f; st.v = v; st.K = deb_key(f, v);
st.mesh = o.mesh0;
st.nSuccess = 0; st.nFail = 0;
end
