function R = qbom(prob, maxFE, o)
%QBOM  Quantum-Based Optimisation Method (Algorithm 1; port of QBOM1.m).
%   R = QBOM(PROB, MAXFE, OPTS) runs QBOM until MAXFE evaluations are used.
if nargin < 3, o = struct(); end
S = fe_init(prob, maxFE);
[st, S] = qbom_init(S, o);
while S.fe < S.maxFE
    [st, S] = qbom_step(st, S, 1);
end
R = run_result(S);
end
