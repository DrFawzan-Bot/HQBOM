function [st, S] = qbom_step(st, S, ngen)
%QBOM_STEP  NGEN generations of the QBOM evolution phase (Algorithm 1),
%   a line-by-line port of QBOM1.m. One generation costs 2n evaluations
%   with local search 1 (n + 2 with local searches 2-4, n without).
%   1 Construct  x_ij <- lb_j + u*(ub_j - lb_j)  if  r_ij > alpha_ij^2
%                (otherwise x_ij is kept); no selection - the population
%                is overwritten, as in QBOM1.m.
%   2 Evaluate   all n vectors; x_best / f_best updated (Deb's rules).
%   3 Local search (ls = 1): n points sampled uniformly in the reduced box
%                [max(lb, x_best - w(ub-lb)), min(ub, x_best + w(ub-lb))];
%                x_best / f_best updated.
%   4 Renew Qubits with the selected gate; for gates 1, 2, 3, 4, 6 only
%                qubits of vectors worse than f_best are updated, the
%                direction depending on sign(x_ij - x_best,j).
if nargin < 3, ngen = 1; end
p = S.prob; o = st.o; rg = p.ub - p.lb; s2 = 1/sqrt(2);
for g = 1:ngen
    if S.fe >= S.maxFE, break; end
    n = st.n; m = p.D;
    % ---- 1. Construct -------------------------------------------------
    M = st.R(1:n,:) > st.A(1:n,:).^2;
    U = p.lb + rand(n, m) .* rg;
    X = st.X(1:n,:); X(M) = U(M);
    % ---- 2. Evaluate --------------------------------------------------
    xbPrev = S.bestX; kbPrev = S.bestK;
    [f, v, X, S, K] = fe_eval(S, X);
    ne = numel(K); if ne == 0, break; end
    st.X(1:ne,:) = X; st.F(1:ne) = f; st.V(1:ne) = v; st.K(1:ne) = K;
    if S.bestK < kbPrev, st.xbestOld = xbPrev; end
    % ---- 3. Local search ----------------------------------------------
    xb = S.bestX;
    switch o.ls
        case 1
            nLB = max(xb - o.w*rg, p.lb);
            if strcmp(o.lsClip, 'original'), nUB = p.ub; else, nUB = min(xb + o.w*rg, p.ub); end
            Y = nLB + rand(n, m) .* (nUB - nLB);
            [~, ~, ~, S] = fe_eval(S, Y);
        case {2, 3, 4}
            r = (xb - st.xbestOld) ./ st.xbestOld;
            if o.ls == 2, dr = max(r); elseif o.ls == 3, dr = min(r); else, dr = mean(r); end
            jump = dr * rg;
            Y = [min(xb + jump, p.ub); max(xb - jump, p.lb)];
            Y(isnan(Y)) = xb(any(isnan(Y),1));
            [~, ~, ~, S] = fe_eval(S, Y);
    end
    % ---- 4. Renew qubits ----------------------------------------------
    xb = S.bestX; kb = S.bestK;
    A = st.A(1:ne,:); Xc = st.X(1:ne,:);
    worse = st.K(1:ne) > kb;
    L = (Xc < xb) & worse;  G = (Xc > xb) & worse;
    B = sqrt(max(0, 1 - A.^2));
    switch o.gate
        case 1   % rotation
            th = zeros(size(A)); th(L) = st.per*pi; th(G) = -st.per*pi;
            A = cos(th).*A - sin(th).*B;
        case 2   % Hadamard
            An = A;
            An(L) =  s2*A(L) + s2*B(L);
            An(G) = -s2*A(G) + s2*B(G);
            A = An;
        case 3   % CNOT
            An = A;
            An(L) =  s2*A(L) - s2*B(L);
            An(G) = -s2*A(G) - s2*B(G);
            A = An;
        case 4   % QNOT
            B0 = st.Beta0(1:ne,:);
            A(L) = B0(L); A(G) = -B0(G);
        case {5, 6}   % Z gate / anti-symmetric C gate (cyclic pattern)
            B0 = st.Beta0(1:ne,:);
            lin = reshape(1:ne*m, m, ne)';          % row-wise loop order
            tt = mod(lin - 1, 3) + 1;
            if o.gate == 5, sel = true(size(A)); else, sel = L; end
            c1 = sel & tt == 1; c2 = sel & tt == 2; c3 = sel & tt == 3;
            An = A; An(c1) = B0(c1); An(c2) = -A(c2); An(c3) = -B0(c3); A = An;
    end
    st.A(1:ne,:) = A;
    st.per = st.per + 1/st.maxIter;
    st.gen = st.gen + 1;
end
end
