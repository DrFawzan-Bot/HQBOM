function o = ps_defaults(o)
%PS_DEFAULTS  Pattern Search (GPS, positive basis 2N, complete poll).
%   mesh0    initial mesh size, fraction of the variable range      0.1
%   meshTol  mesh size below which the poll is considered converged 1e-9
%   expand   mesh expansion factor after a successful poll          2
%   contract mesh contraction factor after an unsuccessful poll     0.5
%   meshMax  largest admissible mesh size                           1
if nargin < 1, o = struct(); end
d = struct('mesh0', 0.1, 'meshTol', 1e-9, 'expand', 2, 'contract', 0.5, ...
           'meshMax', 1);
fn = fieldnames(d);
for k = 1:numel(fn)
    if ~isfield(o, fn{k}), o.(fn{k}) = d.(fn{k}); end
end
end
