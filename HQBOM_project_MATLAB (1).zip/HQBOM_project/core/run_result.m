function R = run_result(S)
%RUN_RESULT  Pack the outcome of one run.
R.bestX    = S.bestX;
R.bestF    = S.bestF;
R.bestV    = S.bestV;
R.feasible = S.bestV <= 0;
R.FEs      = S.fe;
R.feAtBest = S.feAtBest;
R.histF    = S.histF;
R.histV    = S.histV;
end
