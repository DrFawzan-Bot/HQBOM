function [st, S, success] = ps_poll(st, S)
%PS_POLL  One complete poll of Generalized Pattern Search (GPS).
%   Poll set  P = { x + Delta_j * s * e_j : j = 1..D, s = +1,-1 }
%   (maximal positive basis [I, -I], 2D points), where the step on
%   variable j is Delta_j = max(mesh*(ub_j-lb_j), dstep_j) so that discrete
%   variables always move by at least one admissible increment.
%   Points leaving the box are projected onto it; projected points that
%   coincide with x are not evaluated. All remaining points are evaluated
%   (complete poll); the best one (Deb key) replaces x if it is strictly
%   better. Success: mesh <- min(expand*mesh, meshMax);
%   failure: mesh <- contract*mesh.
p = S.prob; D = p.D; o = st.o;
step = st.mesh * (p.ub - p.lb);
if isfield(p, 'dstep'), step = max(step, p.dstep); end
E = full(diag(step));
P = [st.x + E; st.x - E];
P = repair_point(P, p);
keep = any(abs(P - st.x) > 0, 2);
P = P(keep,:);
success = false;
if ~isempty(P)
    [f, v, P, S, K] = fe_eval(S, P);
    if ~isempty(K)
        [kb, i] = min(K);
        if kb < st.K
            st.x = P(i,:); st.f = f(i); st.v = v(i); st.K = kb;
            success = true;
        end
    end
end
if success
    st.mesh = min(o.expand * st.mesh, o.meshMax); st.nSuccess = st.nSuccess + 1;
else
    st.mesh = o.contract * st.mesh;               st.nFail = st.nFail + 1;
end
end
