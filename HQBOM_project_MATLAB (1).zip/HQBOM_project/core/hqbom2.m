function R = hqbom2(prob, maxFE, oq, op, oh)
%HQBOM2  HQBOM-II: QBOM injected into Pattern Search.
%   1. PS starts from a uniformly random point x0 (mesh = mesh0); a QBOM
%      population (Algorithm 1) is initialised once and persists, i.e. it
%      CONTINUES (is not restarted) between injections.
%   2. Each PS iteration performs one complete poll (ps_poll).
%   3. Injection trigger (oh.trigger): 'fail' - after every unsuccessful
%      poll; 'stall' - only when the PS mesh has collapsed (mesh < meshTol).
%      An injection advances QBOM by oh.gInj generations (2*gInj*n FEs).
%      QBOM's local search and qubit renewal use the global x_best, which
%      includes the PS incumbent (information flow PS -> QBOM).
%   4. Transfer QBOM -> PS: if the injection improved x_best, the PS
%      incumbent jumps to x_best and mesh = mesh0.
%   5. Otherwise, if the mesh has collapsed, PS restarts with mesh0 from
%      x_best (oh.restart = 'best') or from the best vector of the current
%      QBOM population (oh.restart = 'qbom', i.e. a new basin; x_best is
%      always retained by FE_EVAL).
%   Budget: FE = FE_PS + sum_k FE_QBOM^(k) <= FEmax (enforced by FE_EVAL).
if nargin < 3, oq = struct(); end
if nargin < 4, op = struct(); end
if nargin < 5, oh = struct(); end
if isnumeric(oh), oh = struct('gInj', oh); end
oh = hqbom_defaults(oh);
op = ps_defaults(op);
S = fe_init(prob, maxFE);
x0 = prob.lb + rand(1, prob.D) .* (prob.ub - prob.lb);
[f0, v0, x0, S] = fe_eval(S, x0);
st = ps_init(x0, f0, v0, op);
[stq, S] = qbom_init(S, oq);
nJump = 0; nInj = 0;
while S.fe < S.maxFE
    [st, S, success] = ps_poll(st, S);
    collapsed = st.mesh < op.meshTol;
    inject = (~success && strcmp(oh.trigger, 'fail')) || collapsed;
    if inject && S.fe < S.maxFE
        kb = S.bestK;
        [stq, S] = qbom_step(stq, S, oh.gInj); nInj = nInj + 1;
        if S.bestK < kb && S.bestK < st.K
            st.x = S.bestX; st.f = S.bestF; st.v = S.bestV; st.K = S.bestK;
            st.mesh = op.mesh0; nJump = nJump + 1; collapsed = false;
        end
    end
    if collapsed
        if strcmp(oh.restart, 'qbom')
            [kq, i] = min(stq.K(1:stq.n));
            st.x = stq.X(i,:); st.f = stq.F(i); st.v = stq.V(i); st.K = kq;
        else
            st.x = S.bestX; st.f = S.bestF; st.v = S.bestV; st.K = S.bestK;
        end
        st.mesh = op.mesh0;
    end
end
R = run_result(S);
R.jumps = nJump; R.injections = nInj;
end
