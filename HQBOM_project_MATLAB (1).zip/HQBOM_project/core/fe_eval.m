function [f, v, X, S, K] = fe_eval(S, X)
%FE_EVAL  Budget-aware evaluation of the rows of X (N-by-D).
%   [F, V, X, S, K] = FE_EVAL(S, X) evaluates at most S.maxFE - S.fe rows
%   of X (extra rows are discarded and NOT returned), after projecting X
%   onto the box [lb, ub] and onto the discrete grid of PROB.dstep.
%   Returns objective F, total constraint violation V (0 = feasible), the
%   repaired points X actually evaluated, the updated structure S, and the
%   scalar Deb key K (see DEB_KEY), which every algorithm uses to compare
%   solutions. The caller must always continue with the returned X.
p   = S.prob;
rem = S.maxFE - S.fe;
if rem <= 0
    f = zeros(0,1); v = f; K = f; X = X([],:); return;
end
if size(X,1) > rem, X = X(1:rem,:); end
X = repair_point(X, p);
[f, v] = p.fobj(X);
f = f(:); v = v(:);
f(isnan(f)) = inf;
K = deb_key(f, v);
n = numel(f);
% --- best-so-far update (Deb's rules are encoded in K) ------------------
[kmin, i] = min(K);
if kmin < S.bestK
    S.bestK = kmin; S.bestF = f(i); S.bestV = v(i); S.bestX = X(i,:);
    S.feAtBest = S.fe + i;
end
S.fe = S.fe + n;
% --- convergence history ---------------------------------------------
while S.ckNext <= numel(S.ck) && S.ck(S.ckNext) <= S.fe
    S.histF(S.ckNext) = S.bestF;
    S.histV(S.ckNext) = S.bestV;
    S.ckNext = S.ckNext + 1;
end
end
