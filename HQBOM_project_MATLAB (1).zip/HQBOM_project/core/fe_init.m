function S = fe_init(prob, maxFE, nCheck)
%FE_INIT  Create the function-evaluation (FE) bookkeeping structure.
%   S = FE_INIT(PROB, MAXFE) prepares a run on problem PROB with a hard
%   budget of MAXFE objective-function evaluations. Every algorithm in this
%   project evaluates candidates ONLY through FE_EVAL, which (i) refuses to
%   exceed MAXFE, (ii) keeps the best-so-far solution under Deb's feasibility
%   rules, and (iii) records a convergence history at NCHECK equally spaced
%   FE checkpoints (default 100).
%
%   PROB fields (see problems/*.m):
%     D, lb, ub      dimension and bound vectors (1-by-D)
%     fobj           handle [f, v] = fobj(X), X is N-by-D, v = total violation
%     dstep          1-by-D discrete step (0 = continuous variable)
%     name           text label
if nargin < 3, nCheck = 100; end
S.prob     = prob;
S.maxFE    = maxFE;
S.fe       = 0;
S.bestX    = [];
S.bestF    = inf;
S.bestV    = inf;
S.bestK    = inf;          % scalar Deb key of the best solution
S.feAtBest = 0;            % FE index at which the final best was first found
S.ck       = ceil((1:nCheck) / nCheck * maxFE);
S.histF    = nan(1, nCheck);
S.histV    = nan(1, nCheck);
S.ckNext   = 1;
end
