function K = deb_key(f, v)
%DEB_KEY  Scalar key reproducing Deb's feasibility rules (Deb, 2000).
%   K < K' holds exactly when the solution with key K is preferred:
%   (1) a feasible solution beats any infeasible one; (2) two feasible
%   solutions are compared by objective value; (3) two infeasible solutions
%   are compared by total constraint violation v.
%   Infeasible keys are BIG*(1+v) with BIG = 1e30, which keeps the full
%   relative precision of v (an additive offset BIG+v would not).
BIG = 1e30;
K = f;
inf_ = v > 0;
K(inf_) = BIG * (1 + v(inf_));
end
