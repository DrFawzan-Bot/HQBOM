# HQBOM — Hybrid Pattern Search / Quantum-Based Optimisation Method

Source code, raw results and analysis scripts for the manuscript
**"Hybrid Pattern Search–Quantum-Based Optimisation Methods (HQBOM-I and
HQBOM-II) for Engineering Optimisation Problems"** (Journal of Engineering
Research, manuscript JER-D-26-02531, revised version).

Everything reported in the revised paper (tables, statistics and figures)
is produced by this repository.

## Contents

| Folder | Content |
|---|---|
| `core/` | QBOM (Algorithm 1; `original_QBOM1_reference.m.txt` is the authors' original code), GPS pattern search (Algorithm 2), HQBOM-I (Algorithm 3), HQBOM-II (Algorithm 4), budget-safe evaluation `fe_eval`, Deb constraint handling `deb_key`, discrete repair `repair_point` |
| `competitors/` | 18 competitor implementations (DE, PSO, GWO, WOA, SCA, AOA, AO, RSA, AVOA, HBA, HGS, SO, GTO, COA, DBO, L-SHADE, iL-SHADE, jSO) |
| `problems/` | CEC2017 wrapper and the seven engineering problems (pressure vessel, spring, IC engine, speed reducer, SCED 2- and 7-generator, CHPED 5-unit) |
| `cec2017/` | Official CEC2017 C code (Suganthan et al.) + MEX gateway `cec17_func.cpp` + `input_data` |
| `stats/` | Friedman / Iman–Davenport test, Holm post-hoc, Wilcoxon rank-sum, Holm adjustment, descriptive statistics |
| `experiments/` | `run_cec2017`, `run_engineering`, `analyze_cec2017`, `analyze_engineering`, `plot_convergence`, registries |
| `results/` | raw run-level MAT files, CSV tables, Excel workbooks |

## Quick start

```matlab
>> main_run_all            % everything (long: ~19k CEC runs)
% or step by step
>> addpath experiments; setup_paths
>> R = hqbom1(pressure_vessel(), 20000)          % one run of HQBOM-I
>> R = hqbom2(cec2017_problem(5,30), 300000)     % one run of HQBOM-II
>> run_cec2017(1:4, [1 3:30], 30)                % HQBOM-I, HQBOM-II, QBOM, PS
>> analyze_cec2017; analyze_engineering
```

The MEX file must be compiled once: `mex cec17_func.cpp` inside `cec2017/`
(MATLAB) or `mkoctfile --mex cec17_func.cpp` (GNU Octave).

## Experimental protocol (fixed in the code)

* CEC2017, D = 30, F1 and F3–F30 (F2 excluded as in the official
  competition), FEmax = 10 000·D = 300 000, 30 independent runs, error
  values below 1e-8 are set to 0.
* Engineering problems: FEmax = 20 000 for every algorithm, 30 runs.
* Seeds: run *r* of CEC function *f* uses `rng(7e6 + 1000*f + r)`; run *r*
  of engineering problem *q* uses `rng(9e6 + 5000*q + r)` — identical for
  every algorithm (see `experiments/seed_base.m`).
* Hybrid parameters were selected by `experiments/tune_hqbom.m` on CEC2017
  D = 10 (disjoint from the test sets); summary in `results/tuning`.
* `run_worker.sh A|B` runs the whole study on two cores (resumable).
* Every evaluation passes through `fe_eval`, which (i) never exceeds
  FEmax, (ii) projects to the bounds and the discrete grid, (iii) keeps
  the best solution with Deb's feasibility rules and (iv) records the
  convergence history.

## Algorithm parameters

| Algorithm | Parameters |
|---|---|
| QBOM | port of the authors' `QBOM1.m` (kept verbatim in `core/original_QBOM1_reference.m.txt`): n = 80, Hadamard gate (option 2), local search 1 with w = 0.15 and the symmetric box (`lsClip='symmetric'`; the literal one-sided box of QBOM1.m is `lsClip='original'`, results in `results/ablation_onesided_box`), one water level r ~ U(0,1); options `gate` 1–6, `ls` 0–4, `Rmode`, `lsClip` |
| PS (GPS) | basis [I, −I] (2D), complete poll, mesh0 = 0.1, ×2 / ×0.5, meshTol = 1e-9, random restarts |
| HQBOM-I | QBOM share ρ = 0.5 of the remaining budget per cycle (tuned), then PS until meshTol |
| HQBOM-II | QBOM injection of gInj = 2 generations (4n FEs) after each unsuccessful poll; after mesh collapse PS restarts from the best QBOM vector (tuned) |
| Competitors | see the header of each file in `competitors/` and Table 3 of the paper |

## Platform used for the reported results

GNU Octave 8.4.0 (64-bit Linux, 2 CPU cores, 8 GB RAM). The code is plain
MATLAB (R2016b or later, no toolbox required) and was written to run
unchanged in both environments; random streams differ between MATLAB and
Octave, so individual run values will differ while the statistics agree
within sampling variability.

## Main results (revised manuscript)

| Test bed | HQBOM-I | HQBOM-II | QBOM | PS | best |
|---|---|---|---|---|---|
| CEC2017 Friedman rank (of 22) | 5 | 7 (tied with PS) | 17 | 8 | iL-SHADE |
| Engineering Friedman rank (of 22) | 8 | 11 | 17 | 6 | jSO |

Excel workbooks: `results/cec2017/HQBOM_CEC2017_results.xlsx`,
`results/engineering/HQBOM_Engineering_results.xlsx` (run-level data,
descriptive statistics with live check formulas, Friedman/Holm/rank-sum
tables, convergence data).

## Licence / citation

Please cite the paper when using this code. The CEC2017 C code is © its
original authors and is redistributed for benchmarking purposes.
